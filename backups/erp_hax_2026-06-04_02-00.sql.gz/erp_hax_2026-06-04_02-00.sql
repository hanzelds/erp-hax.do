--
-- PostgreSQL database dump
--

\restrict 5eiLBrekdCI3gPGSKzfKm5aDCmdDzO5UR5GNpoF3ao5jveFOpy122M0C7j29rrb

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: hax_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO hax_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: hax_user
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AccountType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."AccountType" AS ENUM (
    'ASSET',
    'LIABILITY',
    'EQUITY',
    'INCOME',
    'EXPENSE'
);


ALTER TYPE public."AccountType" OWNER TO hax_user;

--
-- Name: ApprovalStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."ApprovalStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."ApprovalStatus" OWNER TO hax_user;

--
-- Name: AuditAction; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."AuditAction" AS ENUM (
    'CREATE',
    'UPDATE',
    'DELETE',
    'APPROVE',
    'REJECT',
    'CANCEL',
    'SEND',
    'PAY',
    'CLOSE',
    'EMIT',
    'EXPORT',
    'LOGIN'
);


ALTER TYPE public."AuditAction" OWNER TO hax_user;

--
-- Name: BankTransactionStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."BankTransactionStatus" AS ENUM (
    'UNMATCHED',
    'MATCHED',
    'IGNORED'
);


ALTER TYPE public."BankTransactionStatus" OWNER TO hax_user;

--
-- Name: BankTransactionType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."BankTransactionType" AS ENUM (
    'CREDIT',
    'DEBIT'
);


ALTER TYPE public."BankTransactionType" OWNER TO hax_user;

--
-- Name: BudgetStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."BudgetStatus" AS ENUM (
    'ON_TRACK',
    'ALERT',
    'EXCEEDED'
);


ALTER TYPE public."BudgetStatus" OWNER TO hax_user;

--
-- Name: BusinessUnit; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."BusinessUnit" AS ENUM (
    'HAX',
    'KODER'
);


ALTER TYPE public."BusinessUnit" OWNER TO hax_user;

--
-- Name: EmployeeType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."EmployeeType" AS ENUM (
    'SALARIED',
    'CONTRACTOR'
);


ALTER TYPE public."EmployeeType" OWNER TO hax_user;

--
-- Name: ExpenseCategory; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."ExpenseCategory" AS ENUM (
    'OPERATIONS',
    'MARKETING',
    'TECHNOLOGY',
    'RENT',
    'UTILITIES',
    'SALARIES',
    'TAXES',
    'OTHER'
);


ALTER TYPE public."ExpenseCategory" OWNER TO hax_user;

--
-- Name: ExpenseStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."ExpenseStatus" AS ENUM (
    'DRAFT',
    'APPROVED',
    'PAID',
    'CANCELLED'
);


ALTER TYPE public."ExpenseStatus" OWNER TO hax_user;

--
-- Name: FiscalReportType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."FiscalReportType" AS ENUM (
    'REPORT_606',
    'REPORT_607'
);


ALTER TYPE public."FiscalReportType" OWNER TO hax_user;

--
-- Name: FixedAssetCategory; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."FixedAssetCategory" AS ENUM (
    'EQUIPMENT',
    'FURNITURE',
    'VEHICLE',
    'SOFTWARE',
    'IMPROVEMENTS'
);


ALTER TYPE public."FixedAssetCategory" OWNER TO hax_user;

--
-- Name: FixedAssetStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."FixedAssetStatus" AS ENUM (
    'ACTIVE',
    'FULLY_DEPRECIATED',
    'RETIRED'
);


ALTER TYPE public."FixedAssetStatus" OWNER TO hax_user;

--
-- Name: ITBISStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."ITBISStatus" AS ENUM (
    'OPEN',
    'PRE_CLOSED',
    'FILED',
    'PAID',
    'OVERDUE'
);


ALTER TYPE public."ITBISStatus" OWNER TO hax_user;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'SENDING',
    'APPROVED',
    'REJECTED',
    'PAID',
    'CANCELLED',
    'IN_PROCESS'
);


ALTER TYPE public."InvoiceStatus" OWNER TO hax_user;

--
-- Name: InvoiceType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."InvoiceType" AS ENUM (
    'CREDITO_FISCAL',
    'CONSUMO',
    'NOTA_DEBITO',
    'NOTA_CREDITO',
    'COMPRAS',
    'GASTOS_MENORES',
    'REGIMEN_ESPECIAL',
    'GUBERNAMENTAL',
    'EXPORTACIONES',
    'PAGOS_EXTERIOR',
    'PROFORMA'
);


ALTER TYPE public."InvoiceType" OWNER TO hax_user;

--
-- Name: JournalEntryType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."JournalEntryType" AS ENUM (
    'INVOICE',
    'PAYMENT',
    'EXPENSE',
    'PAYROLL',
    'ADJUSTMENT',
    'CREDIT_NOTE'
);


ALTER TYPE public."JournalEntryType" OWNER TO hax_user;

--
-- Name: LeadStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."LeadStatus" AS ENUM (
    'LEAD',
    'CONTACT',
    'PROPOSAL',
    'NEGOTIATION',
    'CLOSED_WON',
    'CLOSED_LOST'
);


ALTER TYPE public."LeadStatus" OWNER TO hax_user;

--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'TRANSFER',
    'CASH',
    'CHECK',
    'CARD'
);


ALTER TYPE public."PaymentMethod" OWNER TO hax_user;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PARTIAL',
    'PAID'
);


ALTER TYPE public."PaymentStatus" OWNER TO hax_user;

--
-- Name: PayrollAdditionType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."PayrollAdditionType" AS ENUM (
    'COMMISSION',
    'OVERTIME',
    'INCENTIVE',
    'BONUS',
    'VACATION_PAY',
    'OTHER'
);


ALTER TYPE public."PayrollAdditionType" OWNER TO hax_user;

--
-- Name: PayrollStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."PayrollStatus" AS ENUM (
    'CALCULATED',
    'APPROVED',
    'PAID'
);


ALTER TYPE public."PayrollStatus" OWNER TO hax_user;

--
-- Name: PdfStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."PdfStatus" AS ENUM (
    'NONE',
    'GENERATING',
    'READY',
    'ERROR'
);


ALTER TYPE public."PdfStatus" OWNER TO hax_user;

--
-- Name: PdfTemplateType; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."PdfTemplateType" AS ENUM (
    'INVOICE',
    'CREDIT_NOTE',
    'QUOTE',
    'PAYROLL_SLIP',
    'REPORT_PNL',
    'REPORT_BALANCE',
    'REPORT_CASHFLOW'
);


ALTER TYPE public."PdfTemplateType" OWNER TO hax_user;

--
-- Name: PurchaseOrderStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."PurchaseOrderStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'CONFIRMED',
    'RECEIVED',
    'CANCELLED'
);


ALTER TYPE public."PurchaseOrderStatus" OWNER TO hax_user;

--
-- Name: QuoteStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."QuoteStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED',
    'CONVERTED'
);


ALTER TYPE public."QuoteStatus" OWNER TO hax_user;

--
-- Name: ReconciliationStatus; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."ReconciliationStatus" AS ENUM (
    'OPEN',
    'CLOSED'
);


ALTER TYPE public."ReconciliationStatus" OWNER TO hax_user;

--
-- Name: RecurringFrequency; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."RecurringFrequency" AS ENUM (
    'WEEKLY',
    'BIWEEKLY',
    'MONTHLY',
    'QUARTERLY',
    'YEARLY'
);


ALTER TYPE public."RecurringFrequency" OWNER TO hax_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: hax_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'ACCOUNTANT'
);


ALTER TYPE public."UserRole" OWNER TO hax_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _PaymentBankTx; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public."_PaymentBankTx" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_PaymentBankTx" OWNER TO hax_user;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type public."AccountType" NOT NULL,
    "parentId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "allowsEntry" boolean DEFAULT true NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.accounts OWNER TO hax_user;

--
-- Name: alanube_requests; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.alanube_requests (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    "requestPayload" jsonb NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status text,
    "responsePayload" jsonb,
    ncf text,
    xml text,
    "errorCode" text,
    "errorMessage" text,
    "receivedAt" timestamp(3) without time zone
);


ALTER TABLE public.alanube_requests OWNER TO hax_user;

--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.approval_requests (
    id text NOT NULL,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    "changeRequested" jsonb NOT NULL,
    reason text,
    status public."ApprovalStatus" DEFAULT 'PENDING'::public."ApprovalStatus" NOT NULL,
    "requestedById" text NOT NULL,
    "approvedById" text,
    "adminNotes" text,
    "resolvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.approval_requests OWNER TO hax_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text NOT NULL,
    action public."AuditAction" NOT NULL,
    entity text NOT NULL,
    "entityId" text NOT NULL,
    before jsonb,
    after jsonb,
    ip text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO hax_user;

--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.bank_accounts (
    id text NOT NULL,
    "businessUnit" public."BusinessUnit",
    name text NOT NULL,
    bank text NOT NULL,
    "accountNumber" text,
    type text DEFAULT 'CHECKING'::text NOT NULL,
    currency text DEFAULT 'DOP'::text NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bank_accounts OWNER TO hax_user;

--
-- Name: bank_reconciliations; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.bank_reconciliations (
    id text NOT NULL,
    period text NOT NULL,
    "bankAccountId" text NOT NULL,
    status public."ReconciliationStatus" DEFAULT 'OPEN'::public."ReconciliationStatus" NOT NULL,
    "closedById" text,
    "closedAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bank_reconciliations OWNER TO hax_user;

--
-- Name: bank_transactions; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.bank_transactions (
    id text NOT NULL,
    "bankAccountId" text NOT NULL,
    type public."BankTransactionType" DEFAULT 'CREDIT'::public."BankTransactionType" NOT NULL,
    amount double precision NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    description text NOT NULL,
    reference text,
    "transactionDate" timestamp(3) without time zone NOT NULL,
    status public."BankTransactionStatus" DEFAULT 'UNMATCHED'::public."BankTransactionStatus" NOT NULL,
    "matchedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.bank_transactions OWNER TO hax_user;

--
-- Name: budgets; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.budgets (
    id text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    period text NOT NULL,
    category text DEFAULT 'TOTAL'::text NOT NULL,
    "amountBudgeted" double precision NOT NULL,
    "amountExecuted" double precision DEFAULT 0 NOT NULL,
    status public."BudgetStatus" DEFAULT 'ON_TRACK'::public."BudgetStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.budgets OWNER TO hax_user;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.clients (
    id text NOT NULL,
    name text NOT NULL,
    "businessName" text,
    rnc text,
    cedula text,
    email text,
    phone text,
    address text,
    city text,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.clients OWNER TO hax_user;

--
-- Name: company_config; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.company_config (
    id text DEFAULT 'main'::text NOT NULL,
    "companyName" text DEFAULT 'HAX ESTUDIO CREATIVO EIRL'::text NOT NULL,
    rnc text DEFAULT '133290251'::text NOT NULL,
    address text,
    phone text,
    email text,
    "logoUrl" text,
    website text,
    "smtpEnabled" boolean DEFAULT false NOT NULL,
    "smtpHost" text,
    "smtpPort" integer DEFAULT 587 NOT NULL,
    "smtpUser" text,
    "smtpPass" text,
    "smtpFrom" text,
    "smtpSsl" boolean DEFAULT false NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_config OWNER TO hax_user;

--
-- Name: crm_opportunities; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.crm_opportunities (
    id text NOT NULL,
    "clientId" text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    title text NOT NULL,
    description text,
    value double precision,
    status public."LeadStatus" DEFAULT 'LEAD'::public."LeadStatus" NOT NULL,
    probability integer DEFAULT 0 NOT NULL,
    "expectedDate" timestamp(3) without time zone,
    "closedAt" timestamp(3) without time zone,
    "closedReason" text,
    "assignedTo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.crm_opportunities OWNER TO hax_user;

--
-- Name: depreciation_entries; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.depreciation_entries (
    id text NOT NULL,
    "assetId" text NOT NULL,
    period text NOT NULL,
    amount double precision NOT NULL,
    "journalEntryId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.depreciation_entries OWNER TO hax_user;

--
-- Name: ecf_config; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.ecf_config (
    id text DEFAULT 'main'::text NOT NULL,
    "legacyNcfEnabled" boolean DEFAULT true NOT NULL,
    "alanubeEnabled" boolean DEFAULT false NOT NULL,
    "alanubeApiKey" text,
    "alanubeEnv" text DEFAULT 'sandbox'::text NOT NULL,
    "alanubeApiUrl" text DEFAULT 'https://api.alanube.com.do'::text NOT NULL,
    "ncfCreditoFiscal" integer DEFAULT 1 NOT NULL,
    "ncfConsumidor" integer DEFAULT 1 NOT NULL,
    "ncfNotaDebito" integer DEFAULT 1 NOT NULL,
    "ncfNotaCredito" integer DEFAULT 1 NOT NULL,
    "ncfCompras" integer DEFAULT 1 NOT NULL,
    "ncfGastosMenores" integer DEFAULT 1 NOT NULL,
    "ncfRegimen" integer DEFAULT 1 NOT NULL,
    "ncfGubernamental" integer DEFAULT 1 NOT NULL,
    "ncfExportaciones" integer DEFAULT 1 NOT NULL,
    "ncfPagosExterior" integer DEFAULT 1 NOT NULL,
    "itbisRate" double precision DEFAULT 0.18 NOT NULL,
    "maxRetroactiveDays" integer DEFAULT 5 NOT NULL,
    "maxRetryCount" integer DEFAULT 5 NOT NULL,
    "autoJournalEntries" boolean DEFAULT true NOT NULL,
    "requireRncB01" boolean DEFAULT true NOT NULL,
    "pollIntervalSeconds" integer DEFAULT 3 NOT NULL,
    "pollTimeoutMinutes" integer DEFAULT 5 NOT NULL,
    "invoiceDueDays" integer DEFAULT 30 NOT NULL,
    "defaultPaymentMethod" text DEFAULT 'TRANSFER'::text NOT NULL,
    "budgetAlertThreshold" double precision DEFAULT 0.8 NOT NULL,
    "budgetExceededThreshold" double precision DEFAULT 1.0 NOT NULL,
    "fixedAssetThreshold" double precision DEFAULT 10000 NOT NULL,
    "payrollAfpEmployee" double precision DEFAULT 0.0287 NOT NULL,
    "payrollAfpEmployer" double precision DEFAULT 0.0710 NOT NULL,
    "payrollSfsEmployee" double precision DEFAULT 0.0304 NOT NULL,
    "payrollSfsEmployer" double precision DEFAULT 0.0709 NOT NULL,
    "payrollRiesgoLaboral" double precision DEFAULT 0.0120 NOT NULL,
    "acctCash" text DEFAULT '1101'::text NOT NULL,
    "acctBank" text DEFAULT '1102'::text NOT NULL,
    "acctReceivables" text DEFAULT '1201'::text NOT NULL,
    "acctItbisReceivable" text DEFAULT '1302'::text NOT NULL,
    "acctPayablesSuppliers" text DEFAULT '2101'::text NOT NULL,
    "acctPayablesEmployees" text DEFAULT '2102'::text NOT NULL,
    "acctPayablesTss" text DEFAULT '2103'::text NOT NULL,
    "acctPayablesIsr" text DEFAULT '2104'::text NOT NULL,
    "acctItbisPayable" text DEFAULT '2201'::text NOT NULL,
    "acctIncomeHax" text DEFAULT '4101'::text NOT NULL,
    "acctIncomeKoder" text DEFAULT '4102'::text NOT NULL,
    "acctExpenseGeneral" text DEFAULT '5101'::text NOT NULL,
    "acctExpenseSalaries" text DEFAULT '5102'::text NOT NULL,
    "acctExpenseMarketing" text DEFAULT '5103'::text NOT NULL,
    "ncfAuthExpiry" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.ecf_config OWNER TO hax_user;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.employees (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    cedula text,
    type public."EmployeeType" DEFAULT 'SALARIED'::public."EmployeeType" NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    "position" text,
    "baseSalary" double precision NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "hiredAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "terminatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.employees OWNER TO hax_user;

--
-- Name: expenses; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.expenses (
    id text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    "supplierId" text,
    supplier text NOT NULL,
    description text NOT NULL,
    amount double precision NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    total double precision NOT NULL,
    category public."ExpenseCategory" DEFAULT 'OPERATIONS'::public."ExpenseCategory" NOT NULL,
    ncf text,
    "receiptUrl" text,
    status public."ExpenseStatus" DEFAULT 'DRAFT'::public."ExpenseStatus" NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "expenseDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "accountCode" text,
    "paymentMethod" text DEFAULT 'TRANSFER'::text,
    "ncfType" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.expenses OWNER TO hax_user;

--
-- Name: fiscal_periods; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.fiscal_periods (
    id text NOT NULL,
    period text NOT NULL,
    "isClosed" boolean DEFAULT false NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "closedBy" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.fiscal_periods OWNER TO hax_user;

--
-- Name: fiscal_reports; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.fiscal_reports (
    id text NOT NULL,
    type public."FiscalReportType" NOT NULL,
    period text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    "recordCount" integer DEFAULT 0 NOT NULL,
    "totalAmount" double precision DEFAULT 0 NOT NULL,
    "totalItbis" double precision DEFAULT 0 NOT NULL,
    "generatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fileUrl" text
);


ALTER TABLE public.fiscal_reports OWNER TO hax_user;

--
-- Name: fixed_assets; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.fixed_assets (
    id text NOT NULL,
    name text NOT NULL,
    category public."FixedAssetCategory" NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    "purchaseDate" timestamp(3) without time zone NOT NULL,
    "purchaseValue" double precision NOT NULL,
    "usefulLifeMonths" integer NOT NULL,
    "salvageValue" double precision DEFAULT 0 NOT NULL,
    "accumulatedDepreciation" double precision DEFAULT 0 NOT NULL,
    "bookValue" double precision NOT NULL,
    status public."FixedAssetStatus" DEFAULT 'ACTIVE'::public."FixedAssetStatus" NOT NULL,
    "supplierId" text,
    "ncfCompra" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.fixed_assets OWNER TO hax_user;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.invoice_items (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    description text NOT NULL,
    "productDescription" text,
    quantity double precision NOT NULL,
    "unitPrice" double precision NOT NULL,
    "discountPct" double precision DEFAULT 0 NOT NULL,
    "taxRate" double precision DEFAULT 0.18 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    subtotal double precision NOT NULL,
    total double precision NOT NULL,
    "isExempt" boolean DEFAULT false NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO hax_user;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    number text NOT NULL,
    "clientId" text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    type public."InvoiceType" DEFAULT 'CREDITO_FISCAL'::public."InvoiceType" NOT NULL,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    "paymentStatus" public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "issueDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "approvedAt" timestamp(3) without time zone,
    "rejectedAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "cancelledAt" timestamp(3) without time zone,
    subtotal double precision DEFAULT 0 NOT NULL,
    "discountAmount" double precision DEFAULT 0 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    total double precision DEFAULT 0 NOT NULL,
    "amountPaid" double precision DEFAULT 0 NOT NULL,
    "amountDue" double precision DEFAULT 0 NOT NULL,
    "paymentTerms" text DEFAULT 'NET_30'::text,
    notes text,
    ncf text,
    xml text,
    "alanubeId" text,
    "alanubeStatus" text,
    "rejectionReason" text,
    "originalInvoiceId" text,
    "fromQuoteId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "pdfPath" text,
    "pdfGeneratedAt" timestamp(3) without time zone,
    "pdfStatus" public."PdfStatus" DEFAULT 'NONE'::public."PdfStatus" NOT NULL,
    "createdById" text
);


ALTER TABLE public.invoices OWNER TO hax_user;

--
-- Name: itbis_periods; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.itbis_periods (
    id text NOT NULL,
    period text NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    status public."ITBISStatus" DEFAULT 'OPEN'::public."ITBISStatus" NOT NULL,
    "totalSalesItbis" double precision DEFAULT 0 NOT NULL,
    "totalPurchasesItbis" double precision DEFAULT 0 NOT NULL,
    "deductibleItbis" double precision DEFAULT 0 NOT NULL,
    "payableItbis" double precision DEFAULT 0 NOT NULL,
    "carryForwardBalance" double precision DEFAULT 0 NOT NULL,
    "prevCarryForward" double precision DEFAULT 0 NOT NULL,
    "declaredAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.itbis_periods OWNER TO hax_user;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.journal_entries (
    id text NOT NULL,
    type public."JournalEntryType" NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    description text NOT NULL,
    "debitAccountId" text NOT NULL,
    "creditAccountId" text NOT NULL,
    amount double precision NOT NULL,
    period text NOT NULL,
    "entryDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isReversed" boolean DEFAULT false NOT NULL,
    "reversedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "invoiceId" text,
    "paymentId" text,
    "expenseId" text,
    "payrollId" text
);


ALTER TABLE public.journal_entries OWNER TO hax_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.payments (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    amount double precision NOT NULL,
    method public."PaymentMethod" DEFAULT 'TRANSFER'::public."PaymentMethod" NOT NULL,
    reference text,
    notes text,
    "paidAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isReversed" boolean DEFAULT false NOT NULL,
    "reversedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.payments OWNER TO hax_user;

--
-- Name: payroll_additions; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.payroll_additions (
    id text NOT NULL,
    "payrollItemId" text NOT NULL,
    type public."PayrollAdditionType" NOT NULL,
    description text,
    amount double precision NOT NULL,
    hours double precision,
    rate double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.payroll_additions OWNER TO hax_user;

--
-- Name: payroll_items; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.payroll_items (
    id text NOT NULL,
    "payrollId" text NOT NULL,
    "employeeId" text NOT NULL,
    "grossSalary" double precision NOT NULL,
    "afpEmployee" double precision DEFAULT 0 NOT NULL,
    "sfsEmployee" double precision DEFAULT 0 NOT NULL,
    isr double precision DEFAULT 0 NOT NULL,
    "otherDeductions" double precision DEFAULT 0 NOT NULL,
    "netSalary" double precision NOT NULL,
    "afpEmployer" double precision DEFAULT 0 NOT NULL,
    "sfsEmployer" double precision DEFAULT 0 NOT NULL,
    "sfsRiesgoLaboral" double precision DEFAULT 0 NOT NULL,
    "emailSent" boolean DEFAULT false NOT NULL,
    "emailSentAt" timestamp(3) without time zone,
    "pdfPath" text,
    "pdfGeneratedAt" timestamp(3) without time zone,
    "pdfStatus" public."PdfStatus" DEFAULT 'NONE'::public."PdfStatus" NOT NULL
);


ALTER TABLE public.payroll_items OWNER TO hax_user;

--
-- Name: payrolls; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.payrolls (
    id text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    period text NOT NULL,
    status public."PayrollStatus" DEFAULT 'CALCULATED'::public."PayrollStatus" NOT NULL,
    "totalGross" double precision NOT NULL,
    "totalAfpEmployee" double precision DEFAULT 0 NOT NULL,
    "totalAfpEmployer" double precision DEFAULT 0 NOT NULL,
    "totalSfsEmployee" double precision DEFAULT 0 NOT NULL,
    "totalSfsEmployer" double precision DEFAULT 0 NOT NULL,
    "totalIsr" double precision DEFAULT 0 NOT NULL,
    "totalOtherDeductions" double precision DEFAULT 0 NOT NULL,
    "totalNet" double precision NOT NULL,
    "totalEmployerCost" double precision DEFAULT 0 NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payrolls OWNER TO hax_user;

--
-- Name: pdf_templates; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.pdf_templates (
    id text NOT NULL,
    type public."PdfTemplateType" NOT NULL,
    name text NOT NULL,
    description text,
    html text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pdf_templates OWNER TO hax_user;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.product_categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_categories OWNER TO hax_user;

--
-- Name: products; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.products (
    id text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    code text,
    name text NOT NULL,
    description text,
    "categoryId" text,
    type text DEFAULT 'SERVICE'::text NOT NULL,
    "unitPrice" double precision DEFAULT 0 NOT NULL,
    "taxRate" double precision DEFAULT 0.18 NOT NULL,
    "isExempt" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO hax_user;

--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.purchase_order_items (
    id text NOT NULL,
    "purchaseOrderId" text NOT NULL,
    description text NOT NULL,
    quantity double precision NOT NULL,
    "unitPrice" double precision NOT NULL,
    "taxRate" double precision DEFAULT 0.18 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    subtotal double precision NOT NULL,
    total double precision NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.purchase_order_items OWNER TO hax_user;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    number text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    "supplierId" text NOT NULL,
    status public."PurchaseOrderStatus" DEFAULT 'DRAFT'::public."PurchaseOrderStatus" NOT NULL,
    notes text,
    subtotal double precision DEFAULT 0 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    total double precision DEFAULT 0 NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "confirmedAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "cancelledAt" timestamp(3) without time zone,
    "expenseId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.purchase_orders OWNER TO hax_user;

--
-- Name: quote_items; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.quote_items (
    id text NOT NULL,
    "quoteId" text NOT NULL,
    description text NOT NULL,
    quantity double precision NOT NULL,
    "unitPrice" double precision NOT NULL,
    "discountPct" double precision DEFAULT 0 NOT NULL,
    "taxRate" double precision DEFAULT 0.18 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    subtotal double precision NOT NULL,
    total double precision NOT NULL,
    "isExempt" boolean DEFAULT false NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.quote_items OWNER TO hax_user;

--
-- Name: quotes; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.quotes (
    id text NOT NULL,
    number text NOT NULL,
    "clientId" text NOT NULL,
    "opportunityId" text,
    "businessUnit" public."BusinessUnit" NOT NULL,
    status public."QuoteStatus" DEFAULT 'DRAFT'::public."QuoteStatus" NOT NULL,
    "validUntil" timestamp(3) without time zone,
    notes text,
    terms text,
    subtotal double precision DEFAULT 0 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    total double precision DEFAULT 0 NOT NULL,
    "convertedInvoiceId" text,
    "convertedAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "acceptedAt" timestamp(3) without time zone,
    "rejectedAt" timestamp(3) without time zone,
    "pdfPath" text,
    "pdfGeneratedAt" timestamp(3) without time zone,
    "pdfStatus" public."PdfStatus" DEFAULT 'NONE'::public."PdfStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.quotes OWNER TO hax_user;

--
-- Name: reconciliation_txs; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.reconciliation_txs (
    id text NOT NULL,
    "reconciliationId" text NOT NULL,
    "txDate" timestamp(3) without time zone NOT NULL,
    description text NOT NULL,
    amount double precision NOT NULL,
    reference text,
    status text DEFAULT 'UNMATCHED'::text NOT NULL,
    "matchedPaymentId" text,
    "matchedExpenseId" text,
    "accountCode" text,
    "classifiedInvoiceId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.reconciliation_txs OWNER TO hax_user;

--
-- Name: recurring_payments; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.recurring_payments (
    id text NOT NULL,
    "businessUnit" public."BusinessUnit" NOT NULL,
    name text NOT NULL,
    description text,
    "supplierId" text,
    supplier text NOT NULL,
    amount double precision NOT NULL,
    category public."ExpenseCategory" DEFAULT 'OPERATIONS'::public."ExpenseCategory" NOT NULL,
    frequency public."RecurringFrequency" DEFAULT 'MONTHLY'::public."RecurringFrequency" NOT NULL,
    "nextDueDate" timestamp(3) without time zone NOT NULL,
    "lastPaidAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "autoGenerate" boolean DEFAULT true NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.recurring_payments OWNER TO hax_user;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    "businessName" text,
    rnc text,
    email text,
    phone text,
    address text,
    city text,
    category public."ExpenseCategory" DEFAULT 'OPERATIONS'::public."ExpenseCategory" NOT NULL,
    "categoryCode" text,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.suppliers OWNER TO hax_user;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.system_settings (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO hax_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hax_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    role public."UserRole" DEFAULT 'ACCOUNTANT'::public."UserRole" NOT NULL,
    permissions jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO hax_user;

--
-- Data for Name: _PaymentBankTx; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public."_PaymentBankTx" ("A", "B") FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.accounts (id, code, name, type, "parentId", "isActive", "allowsEntry", description, "createdAt") FROM stdin;
cmpyr07gn0001f6m39bh4d0qu	1000	Activos	ASSET	\N	t	t	\N	2026-06-04 00:19:37.799
cmpyr07gs0002f6m3jbxssqgv	1100	Activos Corrientes	ASSET	\N	t	t	\N	2026-06-04 00:19:37.804
cmpyr07gu0003f6m3kpp3suq6	1101	Caja	ASSET	\N	t	t	\N	2026-06-04 00:19:37.806
cmpyr07gw0004f6m3sgh4olb1	1102	Banco	ASSET	\N	t	t	\N	2026-06-04 00:19:37.808
cmpyr07gx0005f6m3asmtv84r	1103	Cuentas por Cobrar	ASSET	\N	t	t	\N	2026-06-04 00:19:37.81
cmpyr07gz0006f6m3hari3mb5	1104	ITBIS por Cobrar	ASSET	\N	t	t	\N	2026-06-04 00:19:37.812
cmpyr07h10007f6m3ssm546tb	1200	Activos No Corrientes	ASSET	\N	t	t	\N	2026-06-04 00:19:37.814
cmpyr07h30008f6m3ls9x64cx	1201	Equipos y Mobiliario	ASSET	\N	t	t	\N	2026-06-04 00:19:37.816
cmpyr07hd0009f6m31ykkab9v	2000	Pasivos	LIABILITY	\N	t	t	\N	2026-06-04 00:19:37.818
cmpyr07hj000af6m33vx7sq99	2100	Pasivos Corrientes	LIABILITY	\N	t	t	\N	2026-06-04 00:19:37.831
cmpyr07hk000bf6m3xamauh94	2101	Cuentas por Pagar	LIABILITY	\N	t	t	\N	2026-06-04 00:19:37.833
cmpyr07hm000cf6m3aezw305g	2102	Cuentas por Pagar Empleados	LIABILITY	\N	t	t	\N	2026-06-04 00:19:37.834
cmpyr07ho000df6m3f26aj8cm	2103	ITBIS por Pagar	LIABILITY	\N	t	t	\N	2026-06-04 00:19:37.836
cmpyr07hp000ef6m34nizmr0v	2104	TSS por Pagar	LIABILITY	\N	t	t	\N	2026-06-04 00:19:37.838
cmpyr07hr000ff6m3sguge6ei	2105	ISR por Pagar	LIABILITY	\N	t	t	\N	2026-06-04 00:19:37.839
cmpyr07hs000gf6m3qg0hqnx1	3000	Patrimonio	EQUITY	\N	t	t	\N	2026-06-04 00:19:37.841
cmpyr07hu000hf6m34wmx5gqa	3001	Capital Social	EQUITY	\N	t	t	\N	2026-06-04 00:19:37.843
cmpyr07hw000if6m3x95b6d0s	3002	Utilidades Retenidas	EQUITY	\N	t	t	\N	2026-06-04 00:19:37.844
cmpyr07hx000jf6m31a630g6b	4000	Ingresos	INCOME	\N	t	t	\N	2026-06-04 00:19:37.846
cmpyr07hz000kf6m3xmjff2p7	4001	Ingresos por Servicios Hax	INCOME	\N	t	t	\N	2026-06-04 00:19:37.847
cmpyr07i1000lf6m3ebd03vhd	4002	Ingresos por Servicios Koder	INCOME	\N	t	t	\N	2026-06-04 00:19:37.849
cmpyr07i3000mf6m38t46id6c	4003	Otros Ingresos	INCOME	\N	t	t	\N	2026-06-04 00:19:37.851
cmpyr07i5000nf6m3po15zmav	5000	Gastos	EXPENSE	\N	t	t	\N	2026-06-04 00:19:37.853
cmpyr07i7000of6m3o0mf5c1i	5001	Gastos Operativos	EXPENSE	\N	t	t	\N	2026-06-04 00:19:37.855
cmpyr07i8000pf6m3yll3wa6r	5002	Gastos de Marketing	EXPENSE	\N	t	t	\N	2026-06-04 00:19:37.857
cmpyr07ia000qf6m3naty9myg	5003	Gastos de Nómina	EXPENSE	\N	t	t	\N	2026-06-04 00:19:37.858
cmpyr07ib000rf6m3hcl7xwgn	5004	Gastos de Tecnología	EXPENSE	\N	t	t	\N	2026-06-04 00:19:37.86
cmpyr07id000sf6m3b3oidu2a	5005	Gastos Administrativos	EXPENSE	\N	t	t	\N	2026-06-04 00:19:37.861
\.


--
-- Data for Name: alanube_requests; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.alanube_requests (id, "invoiceId", attempt, "requestPayload", "sentAt", status, "responsePayload", ncf, xml, "errorCode", "errorMessage", "receivedAt") FROM stdin;
\.


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.approval_requests (id, entity, "entityId", "changeRequested", reason, status, "requestedById", "approvedById", "adminNotes", "resolvedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.audit_logs (id, "userId", action, entity, "entityId", before, after, ip, "userAgent", "createdAt") FROM stdin;
cmpyr7gnb0001vzpqe8fz0jo7	cmpyr07ge0000f6m36pehiun1	CREATE	session	cmpyr07ge0000f6m36pehiun1	\N	\N	179.52.83.153	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 00:25:16.295
cmpyrie1f0007vzpq8519vsyp	cmpyr07ge0000f6m36pehiun1	CREATE	invoice	unknown	\N	{"id": "cmpyrie150004vzpqkq3p14bj", "ncf": "B0100000015", "xml": null, "type": "CREDITO_FISCAL", "items": [{"id": "cmpyrie150005vzpq3vc5l6ke", "total": 35400, "taxRate": 0.18, "isExempt": false, "quantity": 1, "subtotal": 30000, "invoiceId": "cmpyrie150004vzpqkq3p14bj", "sortOrder": 0, "taxAmount": 5400, "unitPrice": 30000, "description": "Gestión de Redes Sociales - Personalizado", "discountPct": 0, "productDescription": "10 Publicaciones mensuales en feed\\n1 Reel semanal\\nHasta 4 stories semanales\\nCopywriting publicitario alineado a la marca\\nAsesoría y pauta en campañas de promoción\\n3 Visitas para creación de contenido (fotos y vídeos)\\nReporte trimestral de métricas."}], "notes": null, "total": 35400, "client": {"id": "cmpyr8oik0000ldq65x9ft58u", "rnc": "130242722", "city": null, "name": "AVILA GUILAMO & ASSOCIATES I LAW OFFICE SRL", "email": null, "notes": null, "phone": null, "cedula": null, "address": "La Romana", "isActive": true, "createdAt": "2026-06-04T00:26:13.149Z", "updatedAt": "2026-06-04T00:26:13.149Z", "businessName": null}, "number": "H-000001", "paidAt": null, "sentAt": null, "status": "DRAFT", "dueDate": "2026-06-19T00:00:00.000Z", "pdfPath": null, "clientId": "cmpyr8oik0000ldq65x9ft58u", "subtotal": 30000, "alanubeId": null, "amountDue": 35400, "createdAt": "2026-06-04T00:33:46.121Z", "issueDate": "2026-06-04T00:00:00.000Z", "pdfStatus": "NONE", "taxAmount": 5400, "updatedAt": "2026-06-04T00:33:46.121Z", "amountPaid": 0, "approvedAt": null, "rejectedAt": null, "retryCount": 0, "cancelledAt": null, "createdById": null, "fromQuoteId": null, "businessUnit": "HAX", "paymentTerms": "NET_15", "alanubeStatus": null, "paymentStatus": "PENDING", "discountAmount": 0, "pdfGeneratedAt": null, "rejectionReason": null, "originalInvoiceId": null}	179.52.83.153	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 00:33:46.131
cmpyrifhd0009vzpqd0skm2hx	cmpyr07ge0000f6m36pehiun1	EMIT	invoice	cmpyrie150004vzpqkq3p14bj	\N	{"id": "cmpyrie150004vzpqkq3p14bj", "ncf": "B0100000015", "xml": null, "type": "CREDITO_FISCAL", "notes": null, "total": 35400, "number": "H-000001", "paidAt": null, "sentAt": null, "status": "APPROVED", "dueDate": "2026-06-19T00:00:00.000Z", "pdfPath": null, "clientId": "cmpyr8oik0000ldq65x9ft58u", "subtotal": 30000, "alanubeId": null, "amountDue": 35400, "createdAt": "2026-06-04T00:33:46.121Z", "issueDate": "2026-06-04T00:00:00.000Z", "pdfStatus": "NONE", "taxAmount": 5400, "updatedAt": "2026-06-04T00:33:47.993Z", "amountPaid": 0, "approvedAt": "2026-06-04T00:33:47.992Z", "rejectedAt": null, "retryCount": 0, "cancelledAt": null, "createdById": null, "fromQuoteId": null, "businessUnit": "HAX", "paymentTerms": "NET_15", "alanubeStatus": null, "paymentStatus": "PENDING", "discountAmount": 0, "pdfGeneratedAt": null, "rejectionReason": null, "originalInvoiceId": null}	179.52.83.153	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 00:33:48.001
cmpyrq3sl0006smybd8i4db4l	cmpyr07ge0000f6m36pehiun1	CREATE	invoice	unknown	\N	{"id": "cmpyrq3sb0002smybeem0dn18", "ncf": "B0100000016", "xml": null, "type": "CREDITO_FISCAL", "items": [{"id": "cmpyrq3sb0003smyb0wsn5sgs", "total": 35400, "taxRate": 0.18, "isExempt": false, "quantity": 1, "subtotal": 30000, "invoiceId": "cmpyrq3sb0002smybeem0dn18", "sortOrder": 0, "taxAmount": 5400, "unitPrice": 30000, "description": "Gestión de Redes Sociales - Personalizado", "discountPct": 0, "productDescription": "10 Publicaciones mensuales en feed\\n1 Reel semanal\\nHasta 4 stories semanales\\nCopywriting publicitario alineado a la marca\\nAsesoría y pauta en campañas de promoción\\n3 Visitas para creación de contenido (fotos y vídeos)\\nReporte trimestral de métricas."}, {"id": "cmpyrq3sb0004smybn07ltmqt", "total": 944, "taxRate": 0.18, "isExempt": false, "quantity": 1, "subtotal": 800, "invoiceId": "cmpyrq3sb0002smybeem0dn18", "sortOrder": 1, "taxAmount": 144, "unitPrice": 800, "description": "Publicación de Instagram", "discountPct": 0, "productDescription": null}], "notes": null, "total": 36344, "client": {"id": "cmpyr14xy000d3f8gyzdkvawi", "rnc": null, "city": null, "name": "Marcelle Sanchez", "email": null, "notes": null, "phone": null, "cedula": null, "address": null, "isActive": true, "createdAt": "2026-06-04T00:20:21.190Z", "updatedAt": "2026-06-04T00:20:21.190Z", "businessName": null}, "number": "H-000002", "paidAt": null, "sentAt": null, "status": "DRAFT", "dueDate": null, "pdfPath": null, "clientId": "cmpyr14xy000d3f8gyzdkvawi", "subtotal": 30800, "alanubeId": null, "amountDue": 36344, "createdAt": "2026-06-04T00:39:46.092Z", "issueDate": "2026-06-04T00:00:00.000Z", "pdfStatus": "NONE", "taxAmount": 5544, "updatedAt": "2026-06-04T00:39:46.092Z", "amountPaid": 0, "approvedAt": null, "rejectedAt": null, "retryCount": 0, "cancelledAt": null, "createdById": null, "fromQuoteId": null, "businessUnit": "HAX", "paymentTerms": "NET_30", "alanubeStatus": null, "paymentStatus": "PENDING", "discountAmount": 0, "pdfGeneratedAt": null, "rejectionReason": null, "originalInvoiceId": null}	179.52.83.153	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 00:39:46.102
cmpyvf2bz00014lv32i98nk2d	cmpyr07ge0000f6m36pehiun1	CREATE	session	cmpyr07ge0000f6m36pehiun1	\N	\N	::1	\N	2026-06-04 02:23:09.454
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.bank_accounts (id, "businessUnit", name, bank, "accountNumber", type, currency, balance, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: bank_reconciliations; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.bank_reconciliations (id, period, "bankAccountId", status, "closedById", "closedAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: bank_transactions; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.bank_transactions (id, "bankAccountId", type, amount, balance, description, reference, "transactionDate", status, "matchedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.budgets (id, "businessUnit", period, category, "amountBudgeted", "amountExecuted", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.clients (id, name, "businessName", rnc, cedula, email, phone, address, city, notes, "isActive", "createdAt", "updatedAt") FROM stdin;
cmpyr14xv000c3f8g7k4so4pw	SUMERCA SRL	\N	130630242	\N	\N	\N	La Romana	\N	\N	t	2026-06-04 00:20:21.188	2026-06-04 00:20:21.188
cmpyr14xy000d3f8gyzdkvawi	Marcelle Sanchez	\N	\N	\N	\N	\N	\N	\N	\N	t	2026-06-04 00:20:21.19	2026-06-04 00:20:21.19
cmpyr8oik0000ldq65x9ft58u	AVILA GUILAMO & ASSOCIATES I LAW OFFICE SRL	\N	130242722	\N	\N	\N	La Romana	\N	\N	t	2026-06-04 00:26:13.149	2026-06-04 00:26:13.149
cmpywvvr9000a4lv3lftpc2eg	Lauren Avila	\N	\N	\N	\N	\N	\N	\N	\N	t	2026-06-04 03:04:13.702	2026-06-04 03:04:13.702
\.


--
-- Data for Name: company_config; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.company_config (id, "companyName", rnc, address, phone, email, "logoUrl", website, "smtpEnabled", "smtpHost", "smtpPort", "smtpUser", "smtpPass", "smtpFrom", "smtpSsl", "updatedAt") FROM stdin;
main	HAX ESTUDIO CREATIVO EIRL	133290251	Calle 3ra Benjamin #29, La Romana	809-272-1118	info@hax.com.do	\N	hax.com.do	f	\N	587	\N	\N	\N	f	2026-06-04 00:20:12.011
\.


--
-- Data for Name: crm_opportunities; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.crm_opportunities (id, "clientId", "businessUnit", title, description, value, status, probability, "expectedDate", "closedAt", "closedReason", "assignedTo", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: depreciation_entries; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.depreciation_entries (id, "assetId", period, amount, "journalEntryId", "createdAt") FROM stdin;
\.


--
-- Data for Name: ecf_config; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.ecf_config (id, "legacyNcfEnabled", "alanubeEnabled", "alanubeApiKey", "alanubeEnv", "alanubeApiUrl", "ncfCreditoFiscal", "ncfConsumidor", "ncfNotaDebito", "ncfNotaCredito", "ncfCompras", "ncfGastosMenores", "ncfRegimen", "ncfGubernamental", "ncfExportaciones", "ncfPagosExterior", "itbisRate", "maxRetroactiveDays", "maxRetryCount", "autoJournalEntries", "requireRncB01", "pollIntervalSeconds", "pollTimeoutMinutes", "invoiceDueDays", "defaultPaymentMethod", "budgetAlertThreshold", "budgetExceededThreshold", "fixedAssetThreshold", "payrollAfpEmployee", "payrollAfpEmployer", "payrollSfsEmployee", "payrollSfsEmployer", "payrollRiesgoLaboral", "acctCash", "acctBank", "acctReceivables", "acctItbisReceivable", "acctPayablesSuppliers", "acctPayablesEmployees", "acctPayablesTss", "acctPayablesIsr", "acctItbisPayable", "acctIncomeHax", "acctIncomeKoder", "acctExpenseGeneral", "acctExpenseSalaries", "acctExpenseMarketing", "ncfAuthExpiry", "updatedAt") FROM stdin;
main	t	f	\N	sandbox	https://api.alanube.com.do	17	1	1	1	1	1	1	1	1	1	0.18	5	5	t	f	3	5	30	TRANSFER	0.8	1	10000	0.0287	0.071	0.0304	0.0709	0.012	1101	1102	1201	1302	2101	2102	2103	2104	2201	4101	4102	5101	5102	5103	\N	2026-06-04 00:39:46.088
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.employees (id, name, email, phone, cedula, type, "businessUnit", "position", "baseSalary", "isActive", "hiredAt", "terminatedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.expenses (id, "businessUnit", "supplierId", supplier, description, amount, "taxAmount", total, category, ncf, "receiptUrl", status, "approvedAt", "paidAt", "expenseDate", "accountCode", "paymentMethod", "ncfType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: fiscal_periods; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.fiscal_periods (id, period, "isClosed", "closedAt", "closedBy", notes, "createdAt") FROM stdin;
cmpyr07if000tf6m3edjzz1k2	2026-06	f	\N	\N	\N	2026-06-04 00:19:37.864
\.


--
-- Data for Name: fiscal_reports; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.fiscal_reports (id, type, period, "businessUnit", "recordCount", "totalAmount", "totalItbis", "generatedAt", "fileUrl") FROM stdin;
\.


--
-- Data for Name: fixed_assets; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.fixed_assets (id, name, category, "businessUnit", "purchaseDate", "purchaseValue", "usefulLifeMonths", "salvageValue", "accumulatedDepreciation", "bookValue", status, "supplierId", "ncfCompra", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.invoice_items (id, "invoiceId", description, "productDescription", quantity, "unitPrice", "discountPct", "taxRate", "taxAmount", subtotal, total, "isExempt", "sortOrder") FROM stdin;
cmpyrie150005vzpq3vc5l6ke	cmpyrie150004vzpqkq3p14bj	Gestión de Redes Sociales - Personalizado	10 Publicaciones mensuales en feed\n1 Reel semanal\nHasta 4 stories semanales\nCopywriting publicitario alineado a la marca\nAsesoría y pauta en campañas de promoción\n3 Visitas para creación de contenido (fotos y vídeos)\nReporte trimestral de métricas.	1	30000	0	0.18	5400	30000	35400	f	0
cmpyrq3sb0003smyb0wsn5sgs	cmpyrq3sb0002smybeem0dn18	Gestión de Redes Sociales - Personalizado	10 Publicaciones mensuales en feed\n1 Reel semanal\nHasta 4 stories semanales\nCopywriting publicitario alineado a la marca\nAsesoría y pauta en campañas de promoción\n3 Visitas para creación de contenido (fotos y vídeos)\nReporte trimestral de métricas.	1	30000	0	0.18	5400	30000	35400	f	0
cmpyrq3sb0004smybn07ltmqt	cmpyrq3sb0002smybeem0dn18	Publicación de Instagram	\N	1	800	0	0.18	144	800	944	f	1
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.invoices (id, number, "clientId", "businessUnit", type, status, "paymentStatus", "issueDate", "dueDate", "approvedAt", "rejectedAt", "paidAt", "cancelledAt", subtotal, "discountAmount", "taxAmount", total, "amountPaid", "amountDue", "paymentTerms", notes, ncf, xml, "alanubeId", "alanubeStatus", "rejectionReason", "originalInvoiceId", "fromQuoteId", "createdAt", "updatedAt", "retryCount", "sentAt", "pdfPath", "pdfGeneratedAt", "pdfStatus", "createdById") FROM stdin;
cmpyrie150004vzpqkq3p14bj	H-000001	cmpyr8oik0000ldq65x9ft58u	HAX	CREDITO_FISCAL	APPROVED	PENDING	2026-06-04 00:00:00	2026-06-19 00:00:00	2026-06-04 00:33:47.992	\N	\N	\N	30000	0	5400	35400	0	35400	NET_15	\N	B0100000015	\N	\N	\N	\N	\N	\N	2026-06-04 00:33:46.121	2026-06-04 00:39:12.846	0	\N	\N	\N	ERROR	\N
cmpyrq3sb0002smybeem0dn18	H-000002	cmpyr14xy000d3f8gyzdkvawi	HAX	CREDITO_FISCAL	DRAFT	PENDING	2026-06-04 00:00:00	\N	\N	\N	\N	\N	30800	0	5544	36344	0	36344	NET_30	\N	B0100000016	\N	\N	\N	\N	\N	\N	2026-06-04 00:39:46.092	2026-06-04 00:39:46.092	0	\N	\N	\N	NONE	\N
\.


--
-- Data for Name: itbis_periods; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.itbis_periods (id, period, year, month, "startDate", "endDate", "dueDate", status, "totalSalesItbis", "totalPurchasesItbis", "deductibleItbis", "payableItbis", "carryForwardBalance", "prevCarryForward", "declaredAt", "paidAt", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.journal_entries (id, type, "businessUnit", description, "debitAccountId", "creditAccountId", amount, period, "entryDate", "isReversed", "reversedAt", "createdAt", "invoiceId", "paymentId", "expenseId", "payrollId") FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.payments (id, "invoiceId", amount, method, reference, notes, "paidAt", "isReversed", "reversedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: payroll_additions; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.payroll_additions (id, "payrollItemId", type, description, amount, hours, rate, "createdAt") FROM stdin;
\.


--
-- Data for Name: payroll_items; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.payroll_items (id, "payrollId", "employeeId", "grossSalary", "afpEmployee", "sfsEmployee", isr, "otherDeductions", "netSalary", "afpEmployer", "sfsEmployer", "sfsRiesgoLaboral", "emailSent", "emailSentAt", "pdfPath", "pdfGeneratedAt", "pdfStatus") FROM stdin;
\.


--
-- Data for Name: payrolls; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.payrolls (id, "businessUnit", period, status, "totalGross", "totalAfpEmployee", "totalAfpEmployer", "totalSfsEmployee", "totalSfsEmployer", "totalIsr", "totalOtherDeductions", "totalNet", "totalEmployerCost", "approvedAt", "paidAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: pdf_templates; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.pdf_templates (id, type, name, description, html, "isActive", "createdAt", "updatedAt") FROM stdin;
cmpyr18zn0001fhvbedg0bk9x	CREDIT_NOTE	HAX Bauhaus — Nota de Crédito	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 100px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 8px; line-height: 1.75; }\n    .inv-logo-meta strong { color: #17394f; font-size: 10.5px; letter-spacing: 0.02em; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong><br>\n        RNC {{company.rnc}}<br>\n        {{#if company.address}}{{company.address}}<br>{{/if}}\n        {{#if company.phone}}{{company.phone}}<br>{{/if}}\n        {{#if company.email}}{{company.email}}<br>{{/if}}\n        {{#if invoice.businessUnit}}{{invoice.businessUnit}}{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:20:26.435	2026-06-04 02:23:09.51
cmpyrkryu00017om6ovp0wozf	CREDIT_NOTE	HAX Bauhaus — Nota de Crédito	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:35:37.495	2026-06-04 02:23:09.51
cmpyruyks0001g3d2h1i0xok4	CREDIT_NOTE	HAX Bauhaus — Nota de Crédito	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:43:32.62	2026-06-04 02:23:09.51
cmpyr18zi0000fhvba56c650q	INVOICE	HAX Bauhaus — Factura	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 100px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 8px; line-height: 1.75; }\n    .inv-logo-meta strong { color: #17394f; font-size: 10.5px; letter-spacing: 0.02em; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong><br>\n        RNC {{company.rnc}}<br>\n        {{#if company.address}}{{company.address}}<br>{{/if}}\n        {{#if company.phone}}{{company.phone}}<br>{{/if}}\n        {{#if company.email}}{{company.email}}<br>{{/if}}\n        {{#if invoice.businessUnit}}{{invoice.businessUnit}}{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:20:26.431	2026-06-04 02:23:09.488
cmpyrkryk00007om6ahudyfkv	INVOICE	HAX Bauhaus — Factura	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:35:37.485	2026-06-04 02:23:09.488
cmpyruykm0000g3d2e5bbh282	INVOICE	HAX Bauhaus — Factura	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:43:32.615	2026-06-04 02:23:09.488
cmpys376o000013mdsodmqu22	INVOICE	HAX Bauhaus — Factura	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:49:57.025	2026-06-04 02:23:09.488
cmpys376t000113md1md3i2zn	CREDIT_NOTE	HAX Bauhaus — Nota de Crédito	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:49:57.03	2026-06-04 02:23:09.51
cmpyvf2ci00024lv3te90rznh	INVOICE	HAX Bauhaus — Factura	Diseño Bauhaus Precision — carta 8.5×11in, DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	t	2026-06-04 02:23:09.475	2026-06-04 02:23:09.488
cmpyvf2d800034lv3b2lfqvdp	CREDIT_NOTE	HAX Bauhaus — Nota de Crédito	Diseño Bauhaus Precision — carta 8.5×11in, DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Factura {{invoice.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body {\n      font-family: 'Inter', sans-serif;\n      background: #fff;\n      -webkit-print-color-adjust: exact;\n      print-color-adjust: exact;\n    }\n    .inv {\n      background: #fff;\n      width: 8.5in;\n      min-height: 11in;\n      position: relative;\n      overflow: hidden;\n      display: flex;\n      flex-direction: column;\n    }\n    .inv-watermark {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%) rotate(-35deg);\n      font-size: 96px;\n      font-weight: 700;\n      letter-spacing: 0.08em;\n      pointer-events: none;\n      z-index: 100;\n      white-space: nowrap;\n      opacity: 0.07;\n    }\n    {{#if isPaid}}.inv-watermark { display: block; color: #15803d; }{{/if}}\n    {{#if isCancelled}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    .inv-header {\n      padding: 32px 40px 28px;\n      display: flex;\n      justify-content: space-between;\n      align-items: flex-start;\n      border-bottom: 2px solid #17394f;\n    }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 4px; }\n    .inv-badges { display: flex; gap: 6px; justify-content: flex-end; margin-top: 8px; flex-wrap: wrap; }\n    .badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; }\n    .badge-approved  { background: #dcfce7; color: #15803d; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-cancelled { background: #fee2e2; color: #991b1b; }\n    .badge-paid      { background: #dcfce7; color: #15803d; }\n    .badge-partial   { background: #dbeafe; color: #1d4ed8; }\n    .badge-pending   { background: #fef9c3; color: #854d0e; }\n    .inv-bu { background: #f8fafc; border-bottom: 1px solid #e5e7eb; padding: 8px 40px; display: flex; align-items: center; gap: 8px; }\n    .inv-bu-label { font-size: 9px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: #94a3b8; }\n    .inv-bu-dot { font-size: 10px; color: #94a3b8; }\n    .inv-bu-val { font-size: 11px; font-weight: 500; color: #475569; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .inv-pay-block { padding-top: 13px; border-top: 1px solid #f1f5f9; }\n    .inv-pay-val   { font-size: 13px; font-weight: 600; color: #17394f; }\n    .inv-pay-sub   { font-size: 11px; color: #64748b; margin-top: 2px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd)  { background: #fafbfc; }\n    .inv-row:last-child      { border-bottom: none; }\n    .inv-row-desc  { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; line-height: 1.6; }\n    .inv-row-tax-rate { font-size: 9.5px; color: #94a3b8; display: block; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-paid { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #15803d; font-weight: 500; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 24px; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .mt-10 { margin-top: 10px; }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isPaid}}PAGADA{{/if}}{{#if isCancelled}}ANULADA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if invoice.businessUnit}}<span>{{invoice.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      {{#if invoice.ncf}}\n        <div class="inv-num" style="margin-bottom:2px;">No. {{invoice.number}}</div>\n        <div class="inv-ncf">{{invoice.ncf}}</div>\n      {{else}}\n        <div class="inv-ncf">{{invoice.number}}</div>\n      {{/if}}\n      <div class="inv-doc-type" style="margin-top:4px;">{{invoice.type}}</div>\n    </div>\n  </div>\n\n  {{#if originalNcf}}\n  <div class="inv-orig-ref">Nota de Crédito — Factura de referencia NCF: <strong>{{originalNcf}}</strong></div>\n  {{/if}}\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Facturar a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Emisión</span>\n            <span class="inv-date-val">{{dateShort invoice.issueDate}}</span>\n          </div>\n          {{#if invoice.dueDate}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Vencimiento</span>\n            <span class="inv-date-val">{{dateShort invoice.dueDate}}</span>\n          </div>\n          {{/if}}\n        </div>\n        <div class="inv-pay-block">\n          <span class="lbl">Condición de pago</span>\n          <div class="inv-pay-val">{{invoice.paymentTerms}}</div>\n          {{#if invoice.dueDate}}<div class="inv-pay-sub">Vence el {{date invoice.dueDate}}</div>{{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt invoice.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt invoice.taxAmount}}</span></div>\n      {{#if invoice.amountPaid}}\n      <div class="inv-tot-paid"><span>Pagado</span><span>− {{fmt invoice.amountPaid}}</span></div>\n      {{/if}}\n      <div class="inv-tot-due"><span>Total</span><span>{{fmt invoice.amountDue}}</span></div>\n    </div>\n  </div>\n\n  {{#if invoice.notes}}\n  <div class="inv-notes">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{invoice.notes}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	t	2026-06-04 02:23:09.501	2026-06-04 02:23:09.51
cmpyr18zr0002fhvbld6lpx5h	QUOTE	HAX Bauhaus — Cotización	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html>\n<head><meta charset="UTF-8"><style>\n@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@1,9..144,300;1,9..144,400&family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300&family=Instrument+Sans:wght@300;400;500;600&display=swap');\n*{box-sizing:border-box;margin:0;padding:0}\n@page{size:8.5in 11in;margin:0}\n:root{\n  --brand:#293c4f;--brand-mid:#3d5570;--brand-faint:rgba(41,60,79,.06);\n  --ink:#111827;--ink2:#374151;--mute:#6b7280;--ghost:#9ca3af;\n  --rule:#e5e7eb;--bg:#f9fafb;\n  --red:#b91c1c;--green:#166534;--amber:#92400e;\n  --mono:'DM Mono',monospace;--sans:'Instrument Sans',sans-serif;--serif:'Fraunces',serif;\n}\nbody{font-family:var(--sans);font-size:9pt;color:var(--ink);width:8.5in;min-height:11in;background:#fff;position:relative;-webkit-print-color-adjust:exact;print-color-adjust:exact}\n.wm-brand{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:5.5in;opacity:.03;pointer-events:none;z-index:0}\n.wm-text{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font-family:var(--sans);font-size:110pt;font-weight:600;letter-spacing:.06em;pointer-events:none;z-index:0;white-space:nowrap;opacity:.055}\n.wm-text.red{color:#b91c1c}.wm-text.green{color:#166534}\n.page{position:relative;z-index:1;padding:.52in .6in .48in .65in;min-height:11in;display:flex;flex-direction:column}\n.page::before{content:'';position:fixed;left:0;top:0;bottom:0;width:4px;background:var(--brand)}\n/* header */\n.hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.38in}\n.hdr-logo{height:30px;width:auto;display:block;margin-bottom:9px}\n.hdr-co-name{font-size:7.5pt;font-weight:600;color:var(--brand);letter-spacing:.09em;text-transform:uppercase}\n.hdr-co-meta{font-family:var(--mono);font-size:7pt;color:var(--mute);margin-top:3px;line-height:1.65}\n.hdr-right{text-align:right}\n.doc-title{font-family:var(--serif);font-style:italic;font-size:28pt;font-weight:300;color:var(--brand);letter-spacing:-.02em;line-height:1;margin-bottom:5px}\n.doc-num{font-family:var(--mono);font-size:10.5pt;font-weight:500;color:var(--ink);letter-spacing:.04em}\n.doc-bu{font-family:var(--mono);font-size:6.5pt;color:var(--ghost);letter-spacing:.12em;margin-top:4px;text-transform:uppercase}\n/* rules */\n.rule-brand{height:1.5px;background:var(--brand);margin:.18in 0}\n.rule{height:1px;background:var(--rule);margin:.16in 0}\n/* info grid */\n.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:.35in;margin-bottom:.25in}\n.sec-label{font-size:6pt;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--brand);margin-bottom:7px;padding-bottom:4px;border-bottom:1px solid var(--brand);display:inline-block}\n.client-name{font-size:11pt;font-weight:600;color:var(--ink);margin-bottom:4px}\n.meta-line{font-family:var(--mono);font-size:7.5pt;color:var(--mute);line-height:1.7}\n.det-row{display:flex;gap:10px;margin-bottom:5px;align-items:baseline}\n.det-lbl{font-size:6pt;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--ghost);min-width:58px;flex-shrink:0}\n.det-val{font-family:var(--mono);font-size:8pt;color:var(--ink)}\n.ncf-val{font-family:var(--mono);font-size:9pt;font-weight:500;color:var(--brand);letter-spacing:.04em}\n/* original ref */\n.orig-ref{background:#fffbeb;border-left:3px solid #f59e0b;padding:8px 12px;margin-bottom:.18in;font-size:7.5pt;color:var(--amber);border-radius:0 2px 2px 0}\n/* table */\ntable{width:100%;border-collapse:collapse;margin-bottom:.22in}\nthead tr{border-bottom:2px solid var(--brand)}\nth{font-size:6pt;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--brand);padding:5px 7px 7px}\nth:first-child{text-align:left;padding-left:0}\nth:not(:first-child){text-align:right}\ntbody tr{border-bottom:1px solid var(--rule)}\ntbody tr:nth-child(even){background:var(--bg)}\ntd{padding:8px 7px;font-size:8.5pt;vertical-align:top}\ntd:first-child{text-align:left;padding-left:0}\ntd:not(:first-child){text-align:right;font-family:var(--mono);font-size:8pt;white-space:nowrap}\n.item-desc{color:var(--ink);line-height:1.4}\n.item-exempt{font-size:6.5pt;color:var(--ghost);font-style:italic;margin-top:2px}\n.exempt-label{color:var(--ghost);font-size:7.5pt}\n/* totals */\n.totals-wrap{display:flex;justify-content:flex-end;margin-bottom:.28in}\n.totals{width:3in}\n.t-row{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--rule)}\n.t-row:last-child{border-bottom:none}\n.t-lbl{font-size:7.5pt;color:var(--mute);text-transform:uppercase;letter-spacing:.07em}\n.t-val{font-family:var(--mono);font-size:8.5pt;color:var(--ink)}\n.t-total{background:var(--brand);padding:9px 12px;display:flex;justify-content:space-between;align-items:center;margin-top:3px;border-radius:2px}\n.t-total-lbl{font-size:6.5pt;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.75)}\n.t-total-val{font-family:var(--mono);font-size:13pt;font-weight:500;color:#fff}\n.t-balance{display:flex;justify-content:space-between;padding:5px 12px;background:var(--brand-faint);margin-top:2px}\n.t-balance-lbl{font-size:7pt;color:var(--mute);text-transform:uppercase;letter-spacing:.07em}\n.t-balance-val{font-family:var(--mono);font-size:7.5pt;color:var(--brand);font-weight:500}\n/* discount */\n.t-disc{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--rule)}\n.t-disc-lbl{font-size:7.5pt;color:#92400e;text-transform:uppercase;letter-spacing:.07em}\n.t-disc-val{font-family:var(--mono);font-size:8.5pt;color:#92400e}\n/* notes */\n.notes{margin-bottom:.25in}\n.notes-lbl{font-size:6pt;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--brand);margin-bottom:6px}\n.notes-body{font-size:8pt;color:var(--mute);line-height:1.6;padding:9px 12px;background:var(--bg);border-left:2px solid var(--rule)}\n/* footer */\n.footer{margin-top:auto;padding-top:.14in;border-top:1.5px solid var(--brand);display:flex;justify-content:space-between;align-items:center}\n.footer-brand{font-size:7pt;font-weight:600;color:var(--brand);letter-spacing:.1em;text-transform:uppercase}\n.footer-meta{font-family:var(--mono);font-size:6.5pt;color:var(--ghost);text-align:right;line-height:1.65}\n\n.status-badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:6.5pt;font-weight:600;letter-spacing:.1em;text-transform:uppercase;margin-top:4px}\n.badge-accepted{background:#dcfce7;color:#166534}\n.badge-rejected{background:#fee2e2;color:#991b1b}\n.badge-sent{background:#dbeafe;color:#1e40af}\n.badge-draft{background:#f3f4f6;color:#374151}\n.badge-expired{background:#fff7ed;color:#c2410c}\n.badge-converted{background:#f5f3ff;color:#6d28d9}\n.validity{font-size:7pt;color:var(--ghost);margin-top:3px;font-family:var(--mono)}\n.terms{margin-bottom:.22in}\n.terms-lbl{font-size:6pt;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--brand);margin-bottom:6px}\n.terms-body{font-size:7.5pt;color:var(--mute);line-height:1.6;padding:9px 12px;background:var(--bg);border-left:2px solid var(--rule)}\n</style></head>\n<body>\n\n{{#if isRejected}}<div class="wm-text red">RECHAZADA</div>{{/if}}\n{{#if isConverted}}<div class="wm-text" style="color:#6d28d9;opacity:.05">CONVERTIDA</div>{{/if}}\n<img class="wm-brand" src="{{{logo}}}" alt=""/>\n\n<div class="page">\n\n<div class="hdr">\n  <div>\n    <img class="hdr-logo" src="{{{logo}}}" alt="HAX"/>\n    <div class="hdr-co-name">{{company.name}}</div>\n    <div class="hdr-co-meta">RNC {{company.rnc}}{{#if company.address}}<br>{{company.address}}{{/if}}</div>\n  </div>\n  <div class="hdr-right">\n    <div class="doc-title">Cotización</div>\n    <div class="doc-num">{{quote.number}}</div>\n    <div class="doc-bu">{{quote.businessUnit}}</div>\n    {{#ifEq quote.status "ACEPTADA"}}<span class="status-badge badge-accepted">Aceptada</span>{{/ifEq}}\n    {{#ifEq quote.status "RECHAZADA"}}<span class="status-badge badge-rejected">Rechazada</span>{{/ifEq}}\n    {{#ifEq quote.status "ENVIADA"}}<span class="status-badge badge-sent">Enviada</span>{{/ifEq}}\n    {{#ifEq quote.status "BORRADOR"}}<span class="status-badge badge-draft">Borrador</span>{{/ifEq}}\n    {{#ifEq quote.status "VENCIDA"}}<span class="status-badge badge-expired">Vencida</span>{{/ifEq}}\n    {{#ifEq quote.status "CONVERTIDA"}}<span class="status-badge badge-converted">Convertida</span>{{/ifEq}}\n  </div>\n</div>\n\n<div class="rule-brand"></div>\n\n<div class="info-grid">\n  <div>\n    <div class="sec-label">Dirigida a</div>\n    <div class="client-name">{{client.name}}</div>\n    {{#if client.rnc}}<div class="meta-line">RNC {{client.rnc}}</div>{{/if}}\n    {{#if client.email}}<div class="meta-line">{{client.email}}</div>{{/if}}\n    {{#if client.phone}}<div class="meta-line">{{client.phone}}</div>{{/if}}\n  </div>\n  <div>\n    <div class="sec-label">Detalles</div>\n    <div class="det-row"><span class="det-lbl">Fecha</span><span class="det-val">{{date quote.createdAt}}</span></div>\n    {{#if quote.validUntil}}<div class="det-row"><span class="det-lbl">Válida hasta</span><span class="det-val">{{date quote.validUntil}}</span></div>{{/if}}\n  </div>\n</div>\n\n<div class="rule"></div>\n\n<table>\n  <thead><tr>\n    <th>Descripción</th>\n    <th>Cant.</th>\n    <th>Precio Unit.</th>\n    <th>ITBIS</th>\n    <th>Total</th>\n  </tr></thead>\n  <tbody>\n    {{#each items}}\n    <tr>\n      <td class="item-desc">{{description}}{{#if isExempt}}<div class="item-exempt">Exento de ITBIS</div>{{/if}}</td>\n      <td>{{quantity}}</td>\n      <td>{{fmt unitPrice}}</td>\n      <td>{{#if isExempt}}<span class="exempt-label">Exento</span>{{else}}{{fmt taxAmount}}{{/if}}</td>\n      <td>{{fmt total}}</td>\n    </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<div class="totals-wrap">\n  <div class="totals">\n    <div class="t-row"><span class="t-lbl">Subtotal</span><span class="t-val">{{fmt quote.subtotal}}</span></div>\n    <div class="t-row"><span class="t-lbl">ITBIS (18%)</span><span class="t-val">{{fmt quote.taxAmount}}</span></div>\n    <div class="t-total">\n      <span class="t-total-lbl">Total estimado</span>\n      <span class="t-total-val">{{fmt quote.total}}</span>\n    </div>\n  </div>\n</div>\n\n{{#if quote.terms}}\n<div class="terms">\n  <div class="terms-lbl">Términos y condiciones</div>\n  <div class="terms-body">{{quote.terms}}</div>\n</div>\n{{/if}}\n\n{{#if quote.notes}}\n<div class="notes">\n  <div class="notes-lbl">Notas</div>\n  <div class="notes-body">{{quote.notes}}</div>\n</div>\n{{/if}}\n\n<div class="footer">\n  <div class="footer-brand">{{company.name}} &middot; RNC {{company.rnc}}</div>\n  <div class="footer-meta">Cotización generada {{dateShort generatedAt}}<br>No es un comprobante fiscal</div>\n</div>\n\n</div>\n</body></html>	f	2026-06-04 00:20:26.439	2026-06-04 02:23:09.527
cmpyrkrzx00027om6s3y460c1	QUOTE	HAX Bauhaus — Cotización	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html>\n<head><meta charset="UTF-8"><style>\n@import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@1,9..144,300;1,9..144,400&family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300&family=Instrument+Sans:wght@300;400;500;600&display=swap');\n*{box-sizing:border-box;margin:0;padding:0}\n@page{size:8.5in 11in;margin:0}\n:root{\n  --brand:#293c4f;--brand-mid:#3d5570;--brand-faint:rgba(41,60,79,.06);\n  --ink:#111827;--ink2:#374151;--mute:#6b7280;--ghost:#9ca3af;\n  --rule:#e5e7eb;--bg:#f9fafb;\n  --red:#b91c1c;--green:#166534;--amber:#92400e;\n  --mono:'DM Mono',monospace;--sans:'Instrument Sans',sans-serif;--serif:'Fraunces',serif;\n}\nbody{font-family:var(--sans);font-size:9pt;color:var(--ink);width:8.5in;min-height:11in;background:#fff;position:relative;-webkit-print-color-adjust:exact;print-color-adjust:exact}\n.wm-brand{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:5.5in;opacity:.03;pointer-events:none;z-index:0}\n.wm-text{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font-family:var(--sans);font-size:110pt;font-weight:600;letter-spacing:.06em;pointer-events:none;z-index:0;white-space:nowrap;opacity:.055}\n.wm-text.red{color:#b91c1c}.wm-text.green{color:#166534}\n.page{position:relative;z-index:1;padding:.52in .6in .48in .65in;min-height:11in;display:flex;flex-direction:column}\n.page::before{content:'';position:fixed;left:0;top:0;bottom:0;width:4px;background:var(--brand)}\n/* header */\n.hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.38in}\n.hdr-logo{height:30px;width:auto;display:block;margin-bottom:9px}\n.hdr-co-name{font-size:7.5pt;font-weight:600;color:var(--brand);letter-spacing:.09em;text-transform:uppercase}\n.hdr-co-meta{font-family:var(--mono);font-size:7pt;color:var(--mute);margin-top:3px;line-height:1.65}\n.hdr-right{text-align:right}\n.doc-title{font-family:var(--serif);font-style:italic;font-size:28pt;font-weight:300;color:var(--brand);letter-spacing:-.02em;line-height:1;margin-bottom:5px}\n.doc-num{font-family:var(--mono);font-size:10.5pt;font-weight:500;color:var(--ink);letter-spacing:.04em}\n.doc-bu{font-family:var(--mono);font-size:6.5pt;color:var(--ghost);letter-spacing:.12em;margin-top:4px;text-transform:uppercase}\n/* rules */\n.rule-brand{height:1.5px;background:var(--brand);margin:.18in 0}\n.rule{height:1px;background:var(--rule);margin:.16in 0}\n/* info grid */\n.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:.35in;margin-bottom:.25in}\n.sec-label{font-size:6pt;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--brand);margin-bottom:7px;padding-bottom:4px;border-bottom:1px solid var(--brand);display:inline-block}\n.client-name{font-size:11pt;font-weight:600;color:var(--ink);margin-bottom:4px}\n.meta-line{font-family:var(--mono);font-size:7.5pt;color:var(--mute);line-height:1.7}\n.det-row{display:flex;gap:10px;margin-bottom:5px;align-items:baseline}\n.det-lbl{font-size:6pt;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--ghost);min-width:58px;flex-shrink:0}\n.det-val{font-family:var(--mono);font-size:8pt;color:var(--ink)}\n.ncf-val{font-family:var(--mono);font-size:9pt;font-weight:500;color:var(--brand);letter-spacing:.04em}\n/* original ref */\n.orig-ref{background:#fffbeb;border-left:3px solid #f59e0b;padding:8px 12px;margin-bottom:.18in;font-size:7.5pt;color:var(--amber);border-radius:0 2px 2px 0}\n/* table */\ntable{width:100%;border-collapse:collapse;margin-bottom:.22in}\nthead tr{border-bottom:2px solid var(--brand)}\nth{font-size:6pt;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--brand);padding:5px 7px 7px}\nth:first-child{text-align:left;padding-left:0}\nth:not(:first-child){text-align:right}\ntbody tr{border-bottom:1px solid var(--rule)}\ntbody tr:nth-child(even){background:var(--bg)}\ntd{padding:8px 7px;font-size:8.5pt;vertical-align:top}\ntd:first-child{text-align:left;padding-left:0}\ntd:not(:first-child){text-align:right;font-family:var(--mono);font-size:8pt;white-space:nowrap}\n.item-desc{color:var(--ink);line-height:1.4}\n.item-exempt{font-size:6.5pt;color:var(--ghost);font-style:italic;margin-top:2px}\n.exempt-label{color:var(--ghost);font-size:7.5pt}\n/* totals */\n.totals-wrap{display:flex;justify-content:flex-end;margin-bottom:.28in}\n.totals{width:3in}\n.t-row{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--rule)}\n.t-row:last-child{border-bottom:none}\n.t-lbl{font-size:7.5pt;color:var(--mute);text-transform:uppercase;letter-spacing:.07em}\n.t-val{font-family:var(--mono);font-size:8.5pt;color:var(--ink)}\n.t-total{background:var(--brand);padding:9px 12px;display:flex;justify-content:space-between;align-items:center;margin-top:3px;border-radius:2px}\n.t-total-lbl{font-size:6.5pt;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:rgba(255,255,255,.75)}\n.t-total-val{font-family:var(--mono);font-size:13pt;font-weight:500;color:#fff}\n.t-balance{display:flex;justify-content:space-between;padding:5px 12px;background:var(--brand-faint);margin-top:2px}\n.t-balance-lbl{font-size:7pt;color:var(--mute);text-transform:uppercase;letter-spacing:.07em}\n.t-balance-val{font-family:var(--mono);font-size:7.5pt;color:var(--brand);font-weight:500}\n/* discount */\n.t-disc{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--rule)}\n.t-disc-lbl{font-size:7.5pt;color:#92400e;text-transform:uppercase;letter-spacing:.07em}\n.t-disc-val{font-family:var(--mono);font-size:8.5pt;color:#92400e}\n/* notes */\n.notes{margin-bottom:.25in}\n.notes-lbl{font-size:6pt;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--brand);margin-bottom:6px}\n.notes-body{font-size:8pt;color:var(--mute);line-height:1.6;padding:9px 12px;background:var(--bg);border-left:2px solid var(--rule)}\n/* footer */\n.footer{margin-top:auto;padding-top:.14in;border-top:1.5px solid var(--brand);display:flex;justify-content:space-between;align-items:center}\n.footer-brand{font-size:7pt;font-weight:600;color:var(--brand);letter-spacing:.1em;text-transform:uppercase}\n.footer-meta{font-family:var(--mono);font-size:6.5pt;color:var(--ghost);text-align:right;line-height:1.65}\n\n.status-badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:6.5pt;font-weight:600;letter-spacing:.1em;text-transform:uppercase;margin-top:4px}\n.badge-accepted{background:#dcfce7;color:#166534}\n.badge-rejected{background:#fee2e2;color:#991b1b}\n.badge-sent{background:#dbeafe;color:#1e40af}\n.badge-draft{background:#f3f4f6;color:#374151}\n.badge-expired{background:#fff7ed;color:#c2410c}\n.badge-converted{background:#f5f3ff;color:#6d28d9}\n.validity{font-size:7pt;color:var(--ghost);margin-top:3px;font-family:var(--mono)}\n.terms{margin-bottom:.22in}\n.terms-lbl{font-size:6pt;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--brand);margin-bottom:6px}\n.terms-body{font-size:7.5pt;color:var(--mute);line-height:1.6;padding:9px 12px;background:var(--bg);border-left:2px solid var(--rule)}\n</style></head>\n<body>\n\n{{#if isRejected}}<div class="wm-text red">RECHAZADA</div>{{/if}}\n{{#if isConverted}}<div class="wm-text" style="color:#6d28d9;opacity:.05">CONVERTIDA</div>{{/if}}\n<img class="wm-brand" src="{{{logo}}}" alt=""/>\n\n<div class="page">\n\n<div class="hdr">\n  <div>\n    <img class="hdr-logo" src="{{{logo}}}" alt="HAX"/>\n    <div class="hdr-co-name">{{company.name}}</div>\n    <div class="hdr-co-meta">RNC {{company.rnc}}{{#if company.address}}<br>{{company.address}}{{/if}}</div>\n  </div>\n  <div class="hdr-right">\n    <div class="doc-title">Cotización</div>\n    <div class="doc-num">{{quote.number}}</div>\n    <div class="doc-bu">{{quote.businessUnit}}</div>\n    {{#ifEq quote.status "ACEPTADA"}}<span class="status-badge badge-accepted">Aceptada</span>{{/ifEq}}\n    {{#ifEq quote.status "RECHAZADA"}}<span class="status-badge badge-rejected">Rechazada</span>{{/ifEq}}\n    {{#ifEq quote.status "ENVIADA"}}<span class="status-badge badge-sent">Enviada</span>{{/ifEq}}\n    {{#ifEq quote.status "BORRADOR"}}<span class="status-badge badge-draft">Borrador</span>{{/ifEq}}\n    {{#ifEq quote.status "VENCIDA"}}<span class="status-badge badge-expired">Vencida</span>{{/ifEq}}\n    {{#ifEq quote.status "CONVERTIDA"}}<span class="status-badge badge-converted">Convertida</span>{{/ifEq}}\n  </div>\n</div>\n\n<div class="rule-brand"></div>\n\n<div class="info-grid">\n  <div>\n    <div class="sec-label">Dirigida a</div>\n    <div class="client-name">{{client.name}}</div>\n    {{#if client.rnc}}<div class="meta-line">RNC {{client.rnc}}</div>{{/if}}\n    {{#if client.email}}<div class="meta-line">{{client.email}}</div>{{/if}}\n    {{#if client.phone}}<div class="meta-line">{{client.phone}}</div>{{/if}}\n  </div>\n  <div>\n    <div class="sec-label">Detalles</div>\n    <div class="det-row"><span class="det-lbl">Fecha</span><span class="det-val">{{date quote.createdAt}}</span></div>\n    {{#if quote.validUntil}}<div class="det-row"><span class="det-lbl">Válida hasta</span><span class="det-val">{{date quote.validUntil}}</span></div>{{/if}}\n  </div>\n</div>\n\n<div class="rule"></div>\n\n<table>\n  <thead><tr>\n    <th>Descripción</th>\n    <th>Cant.</th>\n    <th>Precio Unit.</th>\n    <th>ITBIS</th>\n    <th>Total</th>\n  </tr></thead>\n  <tbody>\n    {{#each items}}\n    <tr>\n      <td class="item-desc">{{description}}{{#if isExempt}}<div class="item-exempt">Exento de ITBIS</div>{{/if}}</td>\n      <td>{{quantity}}</td>\n      <td>{{fmt unitPrice}}</td>\n      <td>{{#if isExempt}}<span class="exempt-label">Exento</span>{{else}}{{fmt taxAmount}}{{/if}}</td>\n      <td>{{fmt total}}</td>\n    </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<div class="totals-wrap">\n  <div class="totals">\n    <div class="t-row"><span class="t-lbl">Subtotal</span><span class="t-val">{{fmt quote.subtotal}}</span></div>\n    <div class="t-row"><span class="t-lbl">ITBIS (18%)</span><span class="t-val">{{fmt quote.taxAmount}}</span></div>\n    <div class="t-total">\n      <span class="t-total-lbl">Total estimado</span>\n      <span class="t-total-val">{{fmt quote.total}}</span>\n    </div>\n  </div>\n</div>\n\n{{#if quote.terms}}\n<div class="terms">\n  <div class="terms-lbl">Términos y condiciones</div>\n  <div class="terms-body">{{quote.terms}}</div>\n</div>\n{{/if}}\n\n{{#if quote.notes}}\n<div class="notes">\n  <div class="notes-lbl">Notas</div>\n  <div class="notes-body">{{quote.notes}}</div>\n</div>\n{{/if}}\n\n<div class="footer">\n  <div class="footer-brand">{{company.name}} &middot; RNC {{company.rnc}}</div>\n  <div class="footer-meta">Cotización generada {{dateShort generatedAt}}<br>No es un comprobante fiscal</div>\n</div>\n\n</div>\n</body></html>	f	2026-06-04 00:35:37.534	2026-06-04 02:23:09.527
cmpyruykw0002g3d2m5nqwuee	QUOTE	HAX Bauhaus — Cotización	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Cotización {{quote.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body { font-family: 'Inter', sans-serif; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }\n    .inv { background: #fff; width: 8.5in; min-height: 11in; position: relative; overflow: hidden; display: flex; flex-direction: column; }\n    .inv-watermark { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%) rotate(-35deg); font-size: 96px; font-weight: 700; letter-spacing: 0.08em; pointer-events: none; z-index: 100; white-space: nowrap; opacity: 0.07; }\n    {{#if isRejected}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    {{#if isConverted}}.inv-watermark { display: block; color: #6d28d9; }{{/if}}\n    .inv-header { padding: 32px 40px 28px; display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #17394f; }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-top: 4px; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-bottom: 2px; }\n    .inv-badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-top: 6px; }\n    .badge-accepted  { background: #dcfce7; color: #15803d; }\n    .badge-rejected  { background: #fee2e2; color: #991b1b; }\n    .badge-sent      { background: #dbeafe; color: #1d4ed8; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-expired   { background: #fff7ed; color: #c2410c; }\n    .badge-converted { background: #f5f3ff; color: #6d28d9; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .mt-10 { margin-top: 10px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd) { background: #fafbfc; }\n    .inv-row:last-child { border-bottom: none; }\n    .inv-row-desc { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 0; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-terms { padding: 12px 40px 0; }\n    .inv-terms-text { font-size: 10px; color: #94a3b8; line-height: 1.6; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isRejected}}RECHAZADA{{/if}}{{#if isConverted}}CONVERTIDA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if quote.businessUnit}}<span>{{quote.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      <div class="inv-num">No. {{quote.number}}</div>\n      <div class="inv-ncf">Cotización</div>\n      <div class="inv-doc-type">No es un comprobante fiscal</div>\n      {{#if isAccepted}}<span class="inv-badge badge-accepted">Aceptada</span>{{/if}}\n      {{#if isRejected}}<span class="inv-badge badge-rejected">Rechazada</span>{{/if}}\n      {{#if isConverted}}<span class="inv-badge badge-converted">Convertida</span>{{/if}}\n      {{#ifEq quote.status "SENT"}}<span class="inv-badge badge-sent">Enviada</span>{{/ifEq}}\n      {{#ifEq quote.status "DRAFT"}}<span class="inv-badge badge-draft">Borrador</span>{{/ifEq}}\n      {{#ifEq quote.status "EXPIRED"}}<span class="inv-badge badge-expired">Vencida</span>{{/ifEq}}\n    </div>\n  </div>\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Dirigida a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Fecha</span>\n            <span class="inv-date-val">{{dateShort quote.createdAt}}</span>\n          </div>\n          {{#if quote.validUntil}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Válida hasta</span>\n            <span class="inv-date-val">{{dateShort quote.validUntil}}</span>\n          </div>\n          {{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt quote.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt quote.taxAmount}}</span></div>\n      <div class="inv-tot-due"><span>Total estimado</span><span>{{fmt quote.total}}</span></div>\n    </div>\n  </div>\n\n  {{#if quote.notes}}\n  <div class="inv-notes" style="margin-top:16px;">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{quote.notes}}</div>\n  </div>\n  {{/if}}\n\n  {{#if quote.terms}}\n  <div class="inv-terms" style="margin-top:12px;">\n    <span class="lbl">Términos y condiciones</span>\n    <div class="inv-terms-text">{{quote.terms}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:43:32.624	2026-06-04 02:23:09.527
cmpys376x000213mdavh4pupt	QUOTE	HAX Bauhaus — Cotización	Bauhaus Precision — carta 8.5×11 · DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Cotización {{quote.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body { font-family: 'Inter', sans-serif; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }\n    .inv { background: #fff; width: 8.5in; min-height: 11in; position: relative; overflow: hidden; display: flex; flex-direction: column; }\n    .inv-watermark { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%) rotate(-35deg); font-size: 96px; font-weight: 700; letter-spacing: 0.08em; pointer-events: none; z-index: 100; white-space: nowrap; opacity: 0.07; }\n    {{#if isRejected}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    {{#if isConverted}}.inv-watermark { display: block; color: #6d28d9; }{{/if}}\n    .inv-header { padding: 32px 40px 28px; display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #17394f; }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-top: 4px; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-bottom: 2px; }\n    .inv-badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-top: 6px; }\n    .badge-accepted  { background: #dcfce7; color: #15803d; }\n    .badge-rejected  { background: #fee2e2; color: #991b1b; }\n    .badge-sent      { background: #dbeafe; color: #1d4ed8; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-expired   { background: #fff7ed; color: #c2410c; }\n    .badge-converted { background: #f5f3ff; color: #6d28d9; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .mt-10 { margin-top: 10px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd) { background: #fafbfc; }\n    .inv-row:last-child { border-bottom: none; }\n    .inv-row-desc { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 0; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-terms { padding: 12px 40px 0; }\n    .inv-terms-text { font-size: 10px; color: #94a3b8; line-height: 1.6; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isRejected}}RECHAZADA{{/if}}{{#if isConverted}}CONVERTIDA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if quote.businessUnit}}<span>{{quote.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      <div class="inv-num">No. {{quote.number}}</div>\n      <div class="inv-ncf">Cotización</div>\n      <div class="inv-doc-type">COTIZACIÓN</div>\n      {{#if isAccepted}}<span class="inv-badge badge-accepted">Aceptada</span>{{/if}}\n      {{#if isRejected}}<span class="inv-badge badge-rejected">Rechazada</span>{{/if}}\n      {{#if isConverted}}<span class="inv-badge badge-converted">Convertida</span>{{/if}}\n      {{#ifEq quote.status "SENT"}}<span class="inv-badge badge-sent">Enviada</span>{{/ifEq}}\n      {{#ifEq quote.status "DRAFT"}}<span class="inv-badge badge-draft">Borrador</span>{{/ifEq}}\n      {{#ifEq quote.status "EXPIRED"}}<span class="inv-badge badge-expired">Vencida</span>{{/ifEq}}\n    </div>\n  </div>\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Dirigida a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Fecha</span>\n            <span class="inv-date-val">{{dateShort quote.createdAt}}</span>\n          </div>\n          {{#if quote.validUntil}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Válida hasta</span>\n            <span class="inv-date-val">{{dateShort quote.validUntil}}</span>\n          </div>\n          {{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt quote.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt quote.taxAmount}}</span></div>\n      <div class="inv-tot-due"><span>Total estimado</span><span>{{fmt quote.total}}</span></div>\n    </div>\n  </div>\n\n  {{#if quote.notes}}\n  <div class="inv-notes" style="margin-top:16px;">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{quote.notes}}</div>\n  </div>\n  {{/if}}\n\n  {{#if quote.terms}}\n  <div class="inv-terms" style="margin-top:12px;">\n    <span class="lbl">Términos y condiciones</span>\n    <div class="inv-terms-text">{{quote.terms}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">{{#if quote.validUntil}}Esta cotización es válida hasta el {{date quote.validUntil}}. Después de esta fecha los precios pueden variar.{{else}}Contáctenos para confirmar disponibilidad y precios.{{/if}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	f	2026-06-04 00:49:57.034	2026-06-04 02:23:09.527
cmpyvf2dq00044lv3tcxh4z07	QUOTE	HAX Bauhaus — Cotización	Diseño Bauhaus Precision — carta 8.5×11in, DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Cotización {{quote.number}} — HAX Estudio Creativo</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body { font-family: 'Inter', sans-serif; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }\n    .inv { background: #fff; width: 8.5in; min-height: 11in; position: relative; overflow: hidden; display: flex; flex-direction: column; }\n    .inv-watermark { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%) rotate(-35deg); font-size: 96px; font-weight: 700; letter-spacing: 0.08em; pointer-events: none; z-index: 100; white-space: nowrap; opacity: 0.07; }\n    {{#if isRejected}}.inv-watermark { display: block; color: #991b1b; }{{/if}}\n    {{#if isConverted}}.inv-watermark { display: block; color: #6d28d9; }{{/if}}\n    .inv-header { padding: 32px 40px 28px; display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #17394f; }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-top: 4px; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-bottom: 2px; }\n    .inv-badge { display: inline-block; padding: 3px 10px; border-radius: 3px; font-size: 9.5px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-top: 6px; }\n    .badge-accepted  { background: #dcfce7; color: #15803d; }\n    .badge-rejected  { background: #fee2e2; color: #991b1b; }\n    .badge-sent      { background: #dbeafe; color: #1d4ed8; }\n    .badge-draft     { background: #f1f5f9; color: #64748b; }\n    .badge-expired   { background: #fff7ed; color: #c2410c; }\n    .badge-converted { background: #f5f3ff; color: #6d28d9; }\n    .inv-client { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .inv-client-inner { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .inv-cl-left  { padding: 24px 32px 24px 0; }\n    .inv-cl-divider { background: #e5e7eb; margin: 16px 0; }\n    .inv-cl-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; justify-content: space-between; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .inv-cl-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .inv-cl-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .inv-date-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .inv-date-lbl { font-size: 11px; color: #94a3b8; }\n    .inv-date-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    .mt-10 { margin-top: 10px; }\n    .inv-items-head { background: #f8fafc; padding: 10px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; }\n    .inv-items-head span { font-size: 9.5px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: #94a3b8; }\n    .inv-items-head span:not(:first-child) { text-align: right; }\n    .inv-row { padding: 12px 40px; display: grid; grid-template-columns: 1fr 52px 108px 108px 108px; border-bottom: 1px solid #f1f5f9; align-items: center; }\n    .inv-row:nth-child(odd) { background: #fafbfc; }\n    .inv-row:last-child { border-bottom: none; }\n    .inv-row-desc { font-size: 12.5px; font-weight: 500; color: #0f172a; }\n    .inv-row-product-desc { font-size: 9.5px; color: #94a3b8; margin-top: 3px; line-height: 1.5; white-space: pre-line; }\n    .inv-row-exempt { font-size: 10px; color: #15803d; font-weight: 500; margin-top: 2px; }\n    .inv-row-qty   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-price { font-size: 12.5px; color: #64748b; text-align: right; }\n    .inv-row-tax   { font-size: 12.5px; color: #94a3b8; text-align: right; }\n    .inv-row-tax-exempt { font-size: 11px; color: #15803d; text-align: right; font-weight: 500; }\n    .inv-row-total { font-size: 13px; font-weight: 600; color: #17394f; text-align: right; }\n    .inv-totals-wrap { display: flex; justify-content: flex-end; padding: 20px 40px 0; }\n    .inv-totals { width: 270px; }\n    .inv-tot-row  { display: flex; justify-content: space-between; font-size: 12.5px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; color: #64748b; }\n    .inv-tot-due  { display: flex; justify-content: space-between; font-size: 15px; font-weight: 700; color: #17394f; padding-top: 12px; border-top: 2px solid #17394f; margin-top: 4px; }\n    .inv-notes { padding: 16px 40px 0; border-top: 1px solid #f1f5f9; }\n    .inv-notes-text { font-size: 11.5px; color: #64748b; line-height: 1.6; font-style: italic; }\n    .inv-terms { padding: 12px 40px 0; }\n    .inv-terms-text { font-size: 10px; color: #94a3b8; line-height: 1.6; }\n    .inv-orig-ref { background: #fffbeb; border-left: 3px solid #f59e0b; padding: 8px 12px 8px 40px; font-size: 11px; color: #92400e; }\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-watermark">{{#if isRejected}}RECHAZADA{{/if}}{{#if isConverted}}CONVERTIDA{{/if}}</div>\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n        {{#if quote.businessUnit}}<span>{{quote.businessUnit}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      <div class="inv-num">No. {{quote.number}}</div>\n      <div class="inv-ncf">Cotización</div>\n      <div class="inv-doc-type">COTIZACIÓN</div>\n      {{#if isAccepted}}<span class="inv-badge badge-accepted">Aceptada</span>{{/if}}\n      {{#if isRejected}}<span class="inv-badge badge-rejected">Rechazada</span>{{/if}}\n      {{#if isConverted}}<span class="inv-badge badge-converted">Convertida</span>{{/if}}\n      {{#ifEq quote.status "SENT"}}<span class="inv-badge badge-sent">Enviada</span>{{/ifEq}}\n      {{#ifEq quote.status "DRAFT"}}<span class="inv-badge badge-draft">Borrador</span>{{/ifEq}}\n      {{#ifEq quote.status "EXPIRED"}}<span class="inv-badge badge-expired">Vencida</span>{{/ifEq}}\n    </div>\n  </div>\n\n  <div class="inv-client">\n    <div class="inv-client-inner">\n      <div class="inv-cl-left">\n        <span class="lbl">Dirigida a</span>\n        <div class="inv-cl-name">{{client.name}}</div>\n        {{#if client.rnc}}<div class="inv-cl-sub">RNC {{client.rnc}}</div>{{/if}}\n        {{#if client.email}}<div class="inv-cl-sub">{{client.email}}</div>{{/if}}\n        {{#if client.phone}}<div class="inv-cl-sub">{{client.phone}}</div>{{/if}}\n        {{#if client.address}}<div class="inv-cl-sub">{{client.address}}</div>{{/if}}\n      </div>\n      <div class="inv-cl-divider"></div>\n      <div class="inv-cl-right">\n        <div>\n          <div class="inv-date-row">\n            <span class="inv-date-lbl">Fecha</span>\n            <span class="inv-date-val">{{dateShort quote.createdAt}}</span>\n          </div>\n          {{#if quote.validUntil}}\n          <div class="inv-date-row mt-10">\n            <span class="inv-date-lbl">Válida hasta</span>\n            <span class="inv-date-val">{{dateShort quote.validUntil}}</span>\n          </div>\n          {{/if}}\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="inv-items-head">\n    <span>Descripción</span>\n    <span>Cant.</span>\n    <span>P. Unit.</span>\n    <span>ITBIS</span>\n    <span>Total</span>\n  </div>\n\n  {{#each items}}\n  <div class="inv-row">\n    <div>\n      <div class="inv-row-desc">{{description}}</div>\n      {{#if productDescription}}<div class="inv-row-product-desc">{{productDescription}}</div>{{/if}}\n      {{#if isExempt}}<div class="inv-row-exempt">✓ Exento de ITBIS</div>{{/if}}\n    </div>\n    <div class="inv-row-qty">{{num quantity}}</div>\n    <div class="inv-row-price">{{fmt unitPrice}}</div>\n    <div>\n      {{#if isExempt}}\n        <div class="inv-row-tax-exempt">Exento</div>\n      {{else}}\n        <div class="inv-row-tax">{{fmt taxAmount}}</div>\n      {{/if}}\n    </div>\n    <div class="inv-row-total">{{fmt total}}</div>\n  </div>\n  {{/each}}\n\n  <div class="inv-totals-wrap">\n    <div class="inv-totals">\n      <div class="inv-tot-row"><span>Subtotal</span><span>{{fmt quote.subtotal}}</span></div>\n      <div class="inv-tot-row"><span>ITBIS</span><span>{{fmt quote.taxAmount}}</span></div>\n      <div class="inv-tot-due"><span>Total estimado</span><span>{{fmt quote.total}}</span></div>\n    </div>\n  </div>\n\n  {{#if quote.notes}}\n  <div class="inv-notes" style="margin-top:16px;">\n    <span class="lbl">Notas</span>\n    <div class="inv-notes-text">{{quote.notes}}</div>\n  </div>\n  {{/if}}\n\n  {{#if quote.terms}}\n  <div class="inv-terms" style="margin-top:12px;">\n    <span class="lbl">Términos y condiciones</span>\n    <div class="inv-terms-text">{{quote.terms}}</div>\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">{{#if quote.validUntil}}Esta cotización es válida hasta el {{date quote.validUntil}}. Después de esta fecha los precios pueden variar.{{else}}Contáctenos para confirmar disponibilidad y precios.{{/if}}</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	t	2026-06-04 02:23:09.519	2026-06-04 02:23:09.527
cmpyvf2e900054lv3jujwblg6	PAYROLL_SLIP	HAX Bauhaus — Comprobante Nómina	Diseño Bauhaus Precision — carta 8.5×11in, DM Mono + Instrument Sans + Fraunces	<!DOCTYPE html>\n<html lang="es">\n<head>\n  <meta charset="UTF-8">\n  <title>Nómina {{periodLabel}} — {{employee.name}}</title>\n  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">\n  <style>\n    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }\n    @page { size: 8.5in 11in; margin: 0; }\n    body { font-family: 'Inter', sans-serif; background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }\n    .inv { background: #fff; width: 8.5in; min-height: 11in; position: relative; display: flex; flex-direction: column; }\n    .inv-header { padding: 32px 40px 28px; display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #17394f; }\n    .inv-logo svg { width: 140px; height: auto; display: block; }\n    .inv-logo-meta { font-size: 10px; color: #64748b; margin-top: 10px; line-height: 1.85; }\n    .inv-logo-meta strong { color: #17394f; font-size: 11px; font-weight: 700; letter-spacing: 0.02em; display: block; margin-bottom: 2px; }\n    .inv-logo-meta span { display: block; }\n    .inv-doc { text-align: right; }\n    .inv-doc-type { font-size: 9.5px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-top: 4px; }\n    .inv-ncf { font-size: 26px; font-weight: 700; color: #17394f; letter-spacing: -0.5px; line-height: 1.1; margin-top: 3px; }\n    .inv-num { font-size: 11px; color: #64748b; margin-top: 5px; }\n    /* employee info */\n    .emp-section { padding: 0 40px; border-bottom: 1px solid #e5e7eb; }\n    .emp-grid { display: grid; grid-template-columns: 1fr 1px 220px; }\n    .emp-left { padding: 24px 32px 24px 0; }\n    .emp-divider { background: #e5e7eb; margin: 16px 0; }\n    .emp-right { padding: 24px 0 24px 32px; display: flex; flex-direction: column; gap: 10px; justify-content: center; }\n    .lbl { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: #94a3b8; margin-bottom: 7px; display: block; }\n    .emp-name { font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.35; }\n    .emp-sub { font-size: 11px; color: #64748b; margin-top: 3px; }\n    .det-row { display: flex; justify-content: space-between; align-items: baseline; }\n    .det-lbl { font-size: 11px; color: #94a3b8; }\n    .det-val { font-size: 13px; font-weight: 500; color: #0f172a; }\n    /* pay body */\n    .pay-body { padding: 0 40px; }\n    .pay-section-hd { font-size: 9px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; padding: 16px 0 8px; border-bottom: 2px solid currentColor; margin-bottom: 0; }\n    .pay-section-hd.green { color: #15803d; }\n    .pay-section-hd.red   { color: #b91c1c; }\n    .pay-section-hd.mute  { color: #94a3b8; }\n    .pay-row { display: flex; justify-content: space-between; align-items: center; padding: 9px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px; }\n    .pay-row-lbl { color: #374151; }\n    .pay-row-val { font-weight: 500; color: #0f172a; font-size: 12.5px; }\n    .pay-row-val.red  { color: #b91c1c; }\n    .pay-row-val.mute { color: #94a3b8; font-size: 11px; }\n    .pay-subtotal { display: flex; justify-content: space-between; padding: 9px 0 0; font-size: 11.5px; color: #94a3b8; }\n    /* net salary */\n    .pay-net { margin: 20px 40px; background: #17394f; padding: 16px 24px; display: flex; justify-content: space-between; align-items: center; }\n    .pay-net-lbl { font-size: 10px; font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; color: rgba(255,255,255,0.65); }\n    .pay-net-val { font-size: 22px; font-weight: 700; color: #fff; letter-spacing: -0.5px; }\n    /* employer costs */\n    .pay-patronal { padding: 0 40px; }\n    .pay-patronal-row { display: flex; justify-content: space-between; padding: 7px 0; border-bottom: 1px solid #f1f5f9; font-size: 11px; color: #94a3b8; }\n    /* footer */\n    .inv-footer { background: #17394f; padding: 14px 40px; display: flex; justify-content: space-between; align-items: center; margin-top: auto; }\n    .inv-footer-left { font-size: 10px; color: rgba(255,255,255,0.5); }\n    .inv-footer-right { display: flex; align-items: center; gap: 8px; }\n    .inv-footer-right svg { width: 30px; height: auto; }\n    .inv-footer-right span { font-size: 10px; color: rgba(255,255,255,0.5); }\n  </style>\n</head>\n<body>\n<div class="inv">\n\n  <div class="inv-header">\n    <div class="inv-logo">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <defs><style>.lc{fill:#17394f;stroke-width:0px;}</style></defs>\n        <g><g><g>\n          <path class="lc" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n          <path class="lc" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n        </g></g></g>\n      </svg>\n      <div class="inv-logo-meta">\n        <strong>{{company.name}}</strong>\n        <span>RNC {{company.rnc}}</span>\n        {{#if company.address}}<span>{{company.address}}</span>{{/if}}\n        {{#if company.phone}}<span>{{company.phone}}</span>{{/if}}\n        {{#if company.email}}<span>{{company.email}}</span>{{/if}}\n        {{#if company.website}}<span>{{company.website}}</span>{{/if}}\n      </div>\n    </div>\n    <div class="inv-doc">\n      <div class="inv-ncf">{{periodLabel}}</div>\n      <div class="inv-doc-type">Comprobante de Nómina</div>\n      {{#if payroll.businessUnit}}<div class="inv-num">{{payroll.businessUnit}}</div>{{/if}}\n    </div>\n  </div>\n\n  <div class="emp-section">\n    <div class="emp-grid">\n      <div class="emp-left">\n        <span class="lbl">Empleado</span>\n        <div class="emp-name">{{employee.name}}</div>\n        {{#if employee.position}}<div class="emp-sub">{{employee.position}}</div>{{/if}}\n        {{#if employee.cedula}}<div class="emp-sub">Cédula: {{employee.cedula}}</div>{{/if}}\n        <div class="emp-sub">Tipo: {{#ifEq employee.type "SALARIED"}}Asalariado{{else}}Por hora{{/ifEq}}</div>\n      </div>\n      <div class="emp-divider"></div>\n      <div class="emp-right">\n        <div class="det-row">\n          <span class="det-lbl">Período</span>\n          <span class="det-val">{{periodLabel}}</span>\n        </div>\n        {{#if payroll.paidAt}}\n        <div class="det-row" style="margin-top:10px;">\n          <span class="det-lbl">Fecha de pago</span>\n          <span class="det-val">{{date payroll.paidAt}}</span>\n        </div>\n        {{/if}}\n        <div class="det-row" style="margin-top:10px;">\n          <span class="det-lbl">Método</span>\n          <span class="det-val">Transferencia</span>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class="pay-body">\n\n    <div class="pay-section-hd green">Ingresos</div>\n    <div class="pay-row">\n      <span class="pay-row-lbl">Salario bruto del período</span>\n      <span class="pay-row-val">{{fmt grossSalary}}</span>\n    </div>\n\n    {{#if totalDeductions}}\n    <div class="pay-section-hd red" style="margin-top:8px;">Deducciones</div>\n    {{#if afpEmployee}}\n    <div class="pay-row">\n      <span class="pay-row-lbl">AFP (empleado 2.87%)</span>\n      <span class="pay-row-val red">({{fmt afpEmployee}})</span>\n    </div>\n    {{/if}}\n    {{#if sfsEmployee}}\n    <div class="pay-row">\n      <span class="pay-row-lbl">SFS (empleado 3.04%)</span>\n      <span class="pay-row-val red">({{fmt sfsEmployee}})</span>\n    </div>\n    {{/if}}\n    {{#if isr}}\n    <div class="pay-row">\n      <span class="pay-row-lbl">ISR retenido</span>\n      <span class="pay-row-val red">({{fmt isr}})</span>\n    </div>\n    {{/if}}\n    {{#if otherDeductions}}\n    <div class="pay-row">\n      <span class="pay-row-lbl">Otras deducciones</span>\n      <span class="pay-row-val red">({{fmt otherDeductions}})</span>\n    </div>\n    {{/if}}\n    <div class="pay-subtotal">\n      <span>Total deducciones</span>\n      <span style="color:#b91c1c;font-weight:500;">({{fmt totalDeductions}})</span>\n    </div>\n    {{/if}}\n\n  </div>\n\n  <div class="pay-net">\n    <span class="pay-net-lbl">Salario neto a pagar</span>\n    <span class="pay-net-val">{{fmt netSalary}}</span>\n  </div>\n\n  {{#if afpEmployer}}\n  <div class="pay-patronal">\n    <div class="pay-section-hd mute" style="margin-bottom:0;">Cargas patronales (referencia)</div>\n    {{#if afpEmployer}}\n    <div class="pay-patronal-row">\n      <span>AFP patronal 7.10%</span>\n      <span>{{fmt afpEmployer}}</span>\n    </div>\n    {{/if}}\n    {{#if sfsEmployer}}\n    <div class="pay-patronal-row">\n      <span>SFS patronal 7.09%</span>\n      <span>{{fmt sfsEmployer}}</span>\n    </div>\n    {{/if}}\n    {{#if sfsRiesgoLaboral}}\n    <div class="pay-patronal-row">\n      <span>Riesgo laboral 1.20%</span>\n      <span>{{fmt sfsRiesgoLaboral}}</span>\n    </div>\n    {{/if}}\n  </div>\n  {{/if}}\n\n  <div class="inv-footer">\n    <div class="inv-footer-left">Generado el {{generatedAt}} · Uso interno — no tiene valor fiscal.</div>\n    <div class="inv-footer-right">\n      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 66.5">\n        <path fill="rgba(255,255,255,0.35)" d="m1.36,50.21c.62-.29.97-.45,1.04-.5.07-.05.23-.14.47-.29.24-.14.41-.26.5-.36.1-.1.24-.23.43-.39.19-.17.32-.33.39-.5.07-.17.15-.36.25-.57.1-.22.17-.45.22-.72.05-.26.07-.54.07-.82V10.26c0-.67-.24-1.24-.72-1.72-.48-.48-1.05-.72-1.72-.72H0c1-.62,2.81-1.79,5.41-3.51,2.61-1.72,4.63-3.06,6.06-4.02.62-.38,1.26-.39,1.9-.04.65.36.97.9.97,1.61v22.8c.57-.62,1.1-1.16,1.58-1.61.48-.45,1.04-.96,1.69-1.51.65-.55,1.25-1.03,1.83-1.43.57-.41,1.19-.8,1.86-1.18.67-.38,1.34-.69,2.01-.93.67-.24,1.39-.42,2.15-.54.76-.12,1.54-.15,2.33-.11.79.05,1.61.17,2.47.36,2.77.77,4.88,2.38,6.31,4.84,1.43,2.46,2.15,5.41,2.15,8.86v17.14c0,2.68.33,5.28,1,7.82.67,2.53,1.82,4.73,3.44,6.6,1.63,1.86,3.56,2.82,5.81,2.87,1.39.05,2.75-.22,4.09-.79,1.34-.57,2.2-1.32,2.58-2.22.19-.48.1-.99-.29-1.54-.38-.55-.94-1.23-1.69-2.04-.74-.81-1.28-1.55-1.61-2.22-.91-1.67-.87-3.05.11-4.12.98-1.08,2.55-1.66,4.7-1.76,1.53-.05,2.89.26,4.09.93,1.19.67,2,1.65,2.4,2.94s.08,2.87-.97,4.73c-1.58,2.77-4.15,4.72-7.71,5.84-3.56,1.12-7.33,1.21-11.3.25-2.25-.53-4.24-1.5-5.99-2.9-1.75-1.41-3.11-2.93-4.09-4.55-.98-1.63-1.79-3.43-2.44-5.41-.65-1.98-1.09-3.66-1.33-5.02-.24-1.36-.38-2.69-.43-3.98v-14.06c0-5.5-1.24-8.72-3.73-9.68-.62-.24-1.25-.35-1.9-.32-.65.02-1.22.08-1.72.18-.5.1-1.09.35-1.76.75-.67.41-1.18.74-1.54,1-.36.26-.88.72-1.58,1.36-.69.65-1.14,1.06-1.33,1.25-.19.19-.6.62-1.22,1.29v20.3c0,.29.01.56.04.82.02.26.1.5.22.72.12.22.22.41.29.57.07.17.2.33.39.5.19.17.32.3.39.39.07.1.24.22.5.36.26.14.43.24.5.29.07.05.25.14.54.29s.45.22.5.22H1.36Z"/>\n        <path fill="rgba(255,255,255,0.35)" d="m75.08,45.91c0,.29.02.55.07.79.05.24.1.45.14.65.05.19.13.38.25.57.12.19.22.35.29.47.07.12.2.25.39.39.19.14.33.26.43.36.1.1.25.2.47.32.22.12.36.19.43.22.07.02.23.1.47.22.24.12.41.2.5.25h-8.89c-1.15,0-2.13-.42-2.94-1.25-.81-.84-1.22-1.83-1.22-2.98v-2.08c-4.02,4.21-8.01,6.31-11.98,6.31-3.54,0-6.61-1.19-9.22-3.59-2.61-2.39-3.88-5.09-3.84-8.1.05-1.96.6-3.56,1.65-4.8,1.05-1.24,2.39-2.1,4.02-2.58,1.53-.48,4.37-.86,8.53-1.15,4.16-.29,6.96-.81,8.39-1.58,1.43-.81,2.21-1.86,2.33-3.16.12-1.29-.39-2.46-1.54-3.51-1-.91-2.31-1.58-3.91-2.01-1.6-.43-3.07-.55-4.41-.36,2.39-.91,4.74-1.22,7.06-.93,2.32.29,4.41.93,6.27,1.94,1.86,1,3.37,2.51,4.52,4.52s1.72,4.28,1.72,6.81v14.27Zm8.03-21.59c-1.77-3.2-4.54-5.58-8.32-7.14-3.78-1.55-7.67-2.16-11.69-1.83-2.92.29-5.32,1.22-7.21,2.8-1.89,1.58-2.86,3.68-2.9,6.31,0,1.15-.38,2.14-1.15,2.98-.76.84-1.7,1.26-2.8,1.26-1.34,0-2.27-.57-2.8-1.72-.53-1.15-.48-2.32.14-3.51.62-1.48,1.74-2.86,3.37-4.12,1.62-1.27,3.56-2.32,5.81-3.16,2.25-.84,4.68-1.45,7.31-1.83,2.39-.38,4.86-.59,7.42-.61,2.56-.02,5.21.13,7.96.47,2.75.33,5.24,1.08,7.46,2.22,2.22,1.15,3.84,2.65,4.84,4.52.38.72.79,1.48,1.22,2.29.43.81.91,1.71,1.43,2.65.53.96.94,1.72,1.22,2.29.48.86.81,1.51,1,1.94,2.2-3.01,3.85-5.26,4.95-6.74.43-.53.63-1.04.61-1.54-.03-.5-.28-1.16-.75-1.97-.67-1.15-1.17-2.01-1.51-2.58h6.88c-1.1,1.48-2.75,3.69-4.95,6.63-2.2,2.94-3.85,5.15-4.95,6.63,3.16,5.79,6.41,11.76,9.75,17.93.48.91,1.24,1.36,2.29,1.36h.22v.29h-12.91v-.29h.22c.33,0,.59-.14.75-.43.17-.29.18-.57.04-.86-.72-1.29-1.77-3.24-3.16-5.84-1.39-2.61-2.44-4.58-3.16-5.92-.57.81-1.46,2.02-2.65,3.62-1.2,1.6-2.08,2.79-2.65,3.55-.43.57-.63,1.11-.61,1.61s.27,1.16.75,1.97c.53.86,1.03,1.72,1.51,2.58h-6.88c1.24-1.67,3.02-4.05,5.34-7.14,2.32-3.08,3.98-5.29,4.98-6.63-2.34-4.4-4.11-7.7-5.31-9.9-.14-.29-.36-.68-.65-1.18s-.45-.82-.5-.97Zm-17.64,2.51c-.57,1.24-1.5,2.28-2.76,3.12-1.27.84-2.58,1.48-3.94,1.94-1.36.45-2.7.94-4.02,1.47-1.32.53-2.41,1.22-3.3,2.08-.88.86-1.4,1.94-1.54,3.23-.24,2.73.51,5.02,2.26,6.88,1.74,1.86,3.91,2.51,6.49,1.94,1.96-.43,4.23-2.01,6.81-4.73v-15.92Z"/>\n      </svg>\n      <span>hax.com.do</span>\n    </div>\n  </div>\n\n</div>\n</body></html>	t	2026-06-04 02:23:09.538	2026-06-04 02:23:09.547
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.product_categories (id, name, description, "createdAt") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.products (id, "businessUnit", code, name, description, "categoryId", type, "unitPrice", "taxRate", "isExempt", "isActive", "createdAt", "updatedAt") FROM stdin;
cmpyr0xva0000kgwewja5ldoh	HAX	\N	PLAN LITE - Personalizado	Gestión de Redes Sociales enfocado a contenido semanal:\n• 3 publicaciones semanales.\n• 4 stories semanales.\n• 1 reel semanal\n• Visitas necesarias al mes\n• Community Management.\n• Estrategias de cotenido.\n• Segmentación de anuncios.\n• Informes y estadisticas.	\N	SERVICE	10000	0.18	f	t	2026-06-04 00:20:12.023	2026-06-04 00:27:53.121
cmpyr0xw90008kgwecvbfj0cp	HAX	\N	Gestión de Redes Sociales - Personalizado	10 Publicaciones mensuales en feed\n1 Reel semanal\nHasta 4 stories semanales\nCopywriting publicitario alineado a la marca\nAsesoría y pauta en campañas de promoción\n3 Visitas para creación de contenido (fotos y vídeos)\nReporte trimestral de métricas.	\N	SERVICE	30000	0.18	f	t	2026-06-04 00:20:12.058	2026-06-04 00:30:02.375
cmpyr0xwd000akgweiuh03yuw	HAX	\N	Diseño de valla publicitaria	\N	\N	SERVICE	1500	0.18	f	t	2026-06-04 00:20:12.062	2026-06-04 00:30:02.375
cmpyr0xvl0004kgwehh7hvger	HAX	\N	Corrección al manual de identidad	\N	\N	SERVICE	6000	0.18	f	t	2026-06-04 00:20:12.034	2026-06-04 00:30:02.375
cmpyr0xwf000bkgweohyk1jmg	HAX	\N	Diseño de Flyer	\N	\N	SERVICE	950	0.18	f	t	2026-06-04 00:20:12.063	2026-06-04 00:30:02.375
cmpyr0xvi0002kgwewye6t8rt	HAX	\N	Reels	\N	\N	SERVICE	3000	0.18	f	t	2026-06-04 00:20:12.03	2026-06-04 00:31:38.111
cmpyr0xwb0009kgwe3ljaea3w	HAX	\N	Gestión y asesoria de marca personal	4 Publicaciones mensuales en feed\n1 Reel semanal\nHasta 3 stories semanales\nCopywriting publicitario alineado a la marca\nAsesoría y pauta en campañas de promoción\n2 Visitas para creación de contenido (fotos y vídeos)\nReporte trimestral de métricas	\N	SERVICE	10000	0.18	f	t	2026-06-04 00:20:12.06	2026-06-04 00:31:38.111
cmpyr0xvj0003kgwe0wp4qgzf	HAX	\N	Plantillas de documentos	\N	\N	SERVICE	1000	0.18	f	t	2026-06-04 00:20:12.032	2026-06-04 00:31:38.112
cmpyr0xvg0001kgwexow9cq8k	HAX	\N	Publicación de Instagram	\N	\N	SERVICE	800	0.18	f	t	2026-06-04 00:20:12.028	2026-06-04 00:31:38.112
cmpyr0xw10007kgweazmna255	HAX	\N	Diseño de Catálogo	\N	\N	SERVICE	3000	0.18	f	t	2026-06-04 00:20:12.041	2026-06-04 00:31:38.111
cmpyr0xvo0005kgweh3lo3zu7	HAX	\N	Memorias de venta	\N	\N	SERVICE	3000	0.18	f	t	2026-06-04 00:20:12.037	2026-06-04 00:31:38.111
cmpyr0xvr0006kgwe72vaqycj	HAX	\N	Diseño de Dossier inmobiliario	\N	\N	SERVICE	4000	0.18	f	t	2026-06-04 00:20:12.039	2026-06-04 02:21:04.016
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.purchase_order_items (id, "purchaseOrderId", description, quantity, "unitPrice", "taxRate", "taxAmount", subtotal, total, "sortOrder") FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.purchase_orders (id, number, "businessUnit", "supplierId", status, notes, subtotal, "taxAmount", total, "sentAt", "confirmedAt", "receivedAt", "cancelledAt", "expenseId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: quote_items; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.quote_items (id, "quoteId", description, quantity, "unitPrice", "discountPct", "taxRate", "taxAmount", subtotal, total, "isExempt", "sortOrder") FROM stdin;
cmpyvocx9000026gz87ip5rmu	cmpys18tm00017ub7uwguvw12	Gestión de Redes Sociales - Personalizado	1	30000	0	0	0	30000	30000	f	0
cmpyvocx9000126gzn247ewqx	cmpys18tm00017ub7uwguvw12	Diseño de valla publicitaria	1	1500	0	0	0	1500	1500	f	1
cmpyvocx9000226gz4v23dqs7	cmpys18tm00017ub7uwguvw12	Dirección para valla	1	2000	0	0	0	2000	2000	f	2
cmpyvocx9000326gz5iqza0ys	cmpys18tm00017ub7uwguvw12	Diseño de Dossier inmobiliario	1	4000	0	0	0	4000	4000	f	3
cmpyvocx9000426gzmx79akvf	cmpys18tm00017ub7uwguvw12	Diseño de arte individual	4	800	0	0	0	3200	3200	f	4
cmpyx3q9x000526gz9vag2tf3	cmpywyhnk000c4lv3e46jnmdw	Publicación de Instagram	4	800	0	0	0	3200	3200	f	0
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.quotes (id, number, "clientId", "opportunityId", "businessUnit", status, "validUntil", notes, terms, subtotal, "taxAmount", total, "convertedInvoiceId", "convertedAt", "sentAt", "acceptedAt", "rejectedAt", "pdfPath", "pdfGeneratedAt", "pdfStatus", "createdAt", "updatedAt") FROM stdin;
cmpys18tm00017ub7uwguvw12	COT-H-00001	cmpyr8oik0000ldq65x9ft58u	\N	HAX	DRAFT	\N	\N	\N	40700	0	40700	\N	\N	\N	\N	\N	\N	\N	NONE	2026-06-04 00:48:25.834	2026-06-04 02:30:23.085
cmpywyhnk000c4lv3e46jnmdw	COT-H-00002	cmpywvvr9000a4lv3lftpc2eg	\N	HAX	DRAFT	\N	\N	\N	3200	0	3200	\N	\N	\N	\N	\N	\N	\N	NONE	2026-06-04 03:06:15.393	2026-06-04 03:10:19.846
\.


--
-- Data for Name: reconciliation_txs; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.reconciliation_txs (id, "reconciliationId", "txDate", description, amount, reference, status, "matchedPaymentId", "matchedExpenseId", "accountCode", "classifiedInvoiceId", notes, "createdAt") FROM stdin;
\.


--
-- Data for Name: recurring_payments; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.recurring_payments (id, "businessUnit", name, description, "supplierId", supplier, amount, category, frequency, "nextDueDate", "lastPaidAt", "isActive", "autoGenerate", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.suppliers (id, name, "businessName", rnc, email, phone, address, city, category, "categoryCode", notes, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.system_settings (id, key, value, "updatedAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hax_user
--

COPY public.users (id, name, email, password, role, permissions, "isActive", "lastLogin", "createdAt", "updatedAt") FROM stdin;
cmpyr07ge0000f6m36pehiun1	Hanzel De Los Santos	hanzel@hax.com.do	$2a$12$K2MM4GWmZLhc3BqH2YokFOkLrAshERdOnzE4d9eCuEFUm15eg8XrC	ADMIN	\N	t	2026-06-04 02:23:09.445	2026-06-04 00:19:37.79	2026-06-04 02:23:09.446
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: alanube_requests alanube_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.alanube_requests
    ADD CONSTRAINT alanube_requests_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: bank_reconciliations bank_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: bank_transactions bank_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.bank_transactions
    ADD CONSTRAINT bank_transactions_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: company_config company_config_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.company_config
    ADD CONSTRAINT company_config_pkey PRIMARY KEY (id);


--
-- Name: crm_opportunities crm_opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT crm_opportunities_pkey PRIMARY KEY (id);


--
-- Name: depreciation_entries depreciation_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT depreciation_entries_pkey PRIMARY KEY (id);


--
-- Name: ecf_config ecf_config_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.ecf_config
    ADD CONSTRAINT ecf_config_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_pkey PRIMARY KEY (id);


--
-- Name: fiscal_reports fiscal_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.fiscal_reports
    ADD CONSTRAINT fiscal_reports_pkey PRIMARY KEY (id);


--
-- Name: fixed_assets fixed_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: itbis_periods itbis_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.itbis_periods
    ADD CONSTRAINT itbis_periods_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payroll_additions payroll_additions_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payroll_additions
    ADD CONSTRAINT payroll_additions_pkey PRIMARY KEY (id);


--
-- Name: payroll_items payroll_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payroll_items
    ADD CONSTRAINT payroll_items_pkey PRIMARY KEY (id);


--
-- Name: payrolls payrolls_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payrolls
    ADD CONSTRAINT payrolls_pkey PRIMARY KEY (id);


--
-- Name: pdf_templates pdf_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.pdf_templates
    ADD CONSTRAINT pdf_templates_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: quote_items quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: reconciliation_txs reconciliation_txs_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.reconciliation_txs
    ADD CONSTRAINT reconciliation_txs_pkey PRIMARY KEY (id);


--
-- Name: recurring_payments recurring_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.recurring_payments
    ADD CONSTRAINT recurring_payments_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: _PaymentBankTx_AB_unique; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "_PaymentBankTx_AB_unique" ON public."_PaymentBankTx" USING btree ("A", "B");


--
-- Name: _PaymentBankTx_B_index; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "_PaymentBankTx_B_index" ON public."_PaymentBankTx" USING btree ("B");


--
-- Name: accounts_code_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX accounts_code_idx ON public.accounts USING btree (code);


--
-- Name: accounts_code_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX accounts_code_key ON public.accounts USING btree (code);


--
-- Name: accounts_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "accounts_isActive_idx" ON public.accounts USING btree ("isActive");


--
-- Name: accounts_parentId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "accounts_parentId_idx" ON public.accounts USING btree ("parentId");


--
-- Name: accounts_type_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX accounts_type_idx ON public.accounts USING btree (type);


--
-- Name: alanube_requests_invoiceId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "alanube_requests_invoiceId_idx" ON public.alanube_requests USING btree ("invoiceId");


--
-- Name: alanube_requests_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX alanube_requests_status_idx ON public.alanube_requests USING btree (status);


--
-- Name: approval_requests_entity_entityId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "approval_requests_entity_entityId_idx" ON public.approval_requests USING btree (entity, "entityId");


--
-- Name: approval_requests_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX approval_requests_status_idx ON public.approval_requests USING btree (status);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entity_entityId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "audit_logs_entity_entityId_idx" ON public.audit_logs USING btree (entity, "entityId");


--
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- Name: bank_accounts_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "bank_accounts_businessUnit_idx" ON public.bank_accounts USING btree ("businessUnit");


--
-- Name: bank_accounts_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "bank_accounts_isActive_idx" ON public.bank_accounts USING btree ("isActive");


--
-- Name: bank_reconciliations_period_bankAccountId_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "bank_reconciliations_period_bankAccountId_key" ON public.bank_reconciliations USING btree (period, "bankAccountId");


--
-- Name: bank_reconciliations_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX bank_reconciliations_status_idx ON public.bank_reconciliations USING btree (status);


--
-- Name: bank_transactions_bankAccountId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "bank_transactions_bankAccountId_idx" ON public.bank_transactions USING btree ("bankAccountId");


--
-- Name: bank_transactions_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX bank_transactions_status_idx ON public.bank_transactions USING btree (status);


--
-- Name: bank_transactions_transactionDate_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "bank_transactions_transactionDate_idx" ON public.bank_transactions USING btree ("transactionDate");


--
-- Name: budgets_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "budgets_businessUnit_idx" ON public.budgets USING btree ("businessUnit");


--
-- Name: budgets_businessUnit_period_category_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "budgets_businessUnit_period_category_key" ON public.budgets USING btree ("businessUnit", period, category);


--
-- Name: budgets_period_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX budgets_period_idx ON public.budgets USING btree (period);


--
-- Name: clients_cedula_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX clients_cedula_key ON public.clients USING btree (cedula);


--
-- Name: clients_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "clients_isActive_idx" ON public.clients USING btree ("isActive");


--
-- Name: clients_name_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX clients_name_idx ON public.clients USING btree (name);


--
-- Name: clients_rnc_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX clients_rnc_key ON public.clients USING btree (rnc);


--
-- Name: crm_opportunities_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "crm_opportunities_businessUnit_idx" ON public.crm_opportunities USING btree ("businessUnit");


--
-- Name: crm_opportunities_clientId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "crm_opportunities_clientId_idx" ON public.crm_opportunities USING btree ("clientId");


--
-- Name: crm_opportunities_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX crm_opportunities_status_idx ON public.crm_opportunities USING btree (status);


--
-- Name: depreciation_entries_assetId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "depreciation_entries_assetId_idx" ON public.depreciation_entries USING btree ("assetId");


--
-- Name: depreciation_entries_assetId_period_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "depreciation_entries_assetId_period_key" ON public.depreciation_entries USING btree ("assetId", period);


--
-- Name: depreciation_entries_journalEntryId_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "depreciation_entries_journalEntryId_key" ON public.depreciation_entries USING btree ("journalEntryId");


--
-- Name: depreciation_entries_period_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX depreciation_entries_period_idx ON public.depreciation_entries USING btree (period);


--
-- Name: employees_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "employees_businessUnit_idx" ON public.employees USING btree ("businessUnit");


--
-- Name: employees_cedula_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX employees_cedula_key ON public.employees USING btree (cedula);


--
-- Name: employees_email_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX employees_email_key ON public.employees USING btree (email);


--
-- Name: employees_type_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "employees_type_isActive_idx" ON public.employees USING btree (type, "isActive");


--
-- Name: expenses_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "expenses_businessUnit_idx" ON public.expenses USING btree ("businessUnit");


--
-- Name: expenses_category_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX expenses_category_idx ON public.expenses USING btree (category);


--
-- Name: expenses_expenseDate_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "expenses_expenseDate_idx" ON public.expenses USING btree ("expenseDate");


--
-- Name: expenses_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX expenses_status_idx ON public.expenses USING btree (status);


--
-- Name: expenses_supplierId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "expenses_supplierId_idx" ON public.expenses USING btree ("supplierId");


--
-- Name: fiscal_periods_isClosed_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "fiscal_periods_isClosed_idx" ON public.fiscal_periods USING btree ("isClosed");


--
-- Name: fiscal_periods_period_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX fiscal_periods_period_key ON public.fiscal_periods USING btree (period);


--
-- Name: fiscal_reports_period_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX fiscal_reports_period_idx ON public.fiscal_reports USING btree (period);


--
-- Name: fiscal_reports_type_period_businessUnit_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "fiscal_reports_type_period_businessUnit_key" ON public.fiscal_reports USING btree (type, period, "businessUnit");


--
-- Name: fixed_assets_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "fixed_assets_businessUnit_idx" ON public.fixed_assets USING btree ("businessUnit");


--
-- Name: fixed_assets_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX fixed_assets_status_idx ON public.fixed_assets USING btree (status);


--
-- Name: invoice_items_invoiceId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "invoice_items_invoiceId_idx" ON public.invoice_items USING btree ("invoiceId");


--
-- Name: invoices_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "invoices_businessUnit_idx" ON public.invoices USING btree ("businessUnit");


--
-- Name: invoices_clientId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "invoices_clientId_idx" ON public.invoices USING btree ("clientId");


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_fromQuoteId_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "invoices_fromQuoteId_key" ON public.invoices USING btree ("fromQuoteId");


--
-- Name: invoices_issueDate_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "invoices_issueDate_idx" ON public.invoices USING btree ("issueDate");


--
-- Name: invoices_ncf_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX invoices_ncf_idx ON public.invoices USING btree (ncf);


--
-- Name: invoices_number_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX invoices_number_key ON public.invoices USING btree (number);


--
-- Name: invoices_paymentStatus_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "invoices_paymentStatus_idx" ON public.invoices USING btree ("paymentStatus");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: itbis_periods_period_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX itbis_periods_period_key ON public.itbis_periods USING btree (period);


--
-- Name: itbis_periods_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX itbis_periods_status_idx ON public.itbis_periods USING btree (status);


--
-- Name: itbis_periods_year_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX itbis_periods_year_idx ON public.itbis_periods USING btree (year);


--
-- Name: journal_entries_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "journal_entries_businessUnit_idx" ON public.journal_entries USING btree ("businessUnit");


--
-- Name: journal_entries_entryDate_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "journal_entries_entryDate_idx" ON public.journal_entries USING btree ("entryDate");


--
-- Name: journal_entries_expenseId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "journal_entries_expenseId_idx" ON public.journal_entries USING btree ("expenseId");


--
-- Name: journal_entries_invoiceId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "journal_entries_invoiceId_idx" ON public.journal_entries USING btree ("invoiceId");


--
-- Name: journal_entries_paymentId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "journal_entries_paymentId_idx" ON public.journal_entries USING btree ("paymentId");


--
-- Name: journal_entries_period_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX journal_entries_period_idx ON public.journal_entries USING btree (period);


--
-- Name: journal_entries_type_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX journal_entries_type_idx ON public.journal_entries USING btree (type);


--
-- Name: payments_invoiceId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "payments_invoiceId_idx" ON public.payments USING btree ("invoiceId");


--
-- Name: payments_paidAt_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "payments_paidAt_idx" ON public.payments USING btree ("paidAt");


--
-- Name: payroll_additions_payrollItemId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "payroll_additions_payrollItemId_idx" ON public.payroll_additions USING btree ("payrollItemId");


--
-- Name: payroll_items_payrollId_employeeId_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "payroll_items_payrollId_employeeId_key" ON public.payroll_items USING btree ("payrollId", "employeeId");


--
-- Name: payroll_items_payrollId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "payroll_items_payrollId_idx" ON public.payroll_items USING btree ("payrollId");


--
-- Name: payrolls_businessUnit_period_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "payrolls_businessUnit_period_key" ON public.payrolls USING btree ("businessUnit", period);


--
-- Name: payrolls_period_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX payrolls_period_idx ON public.payrolls USING btree (period);


--
-- Name: payrolls_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX payrolls_status_idx ON public.payrolls USING btree (status);


--
-- Name: pdf_templates_type_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "pdf_templates_type_isActive_idx" ON public.pdf_templates USING btree (type, "isActive");


--
-- Name: product_categories_name_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX product_categories_name_key ON public.product_categories USING btree (name);


--
-- Name: products_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "products_businessUnit_idx" ON public.products USING btree ("businessUnit");


--
-- Name: products_categoryId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "products_categoryId_idx" ON public.products USING btree ("categoryId");


--
-- Name: products_code_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX products_code_key ON public.products USING btree (code);


--
-- Name: products_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "products_isActive_idx" ON public.products USING btree ("isActive");


--
-- Name: purchase_order_items_purchaseOrderId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "purchase_order_items_purchaseOrderId_idx" ON public.purchase_order_items USING btree ("purchaseOrderId");


--
-- Name: purchase_orders_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "purchase_orders_businessUnit_idx" ON public.purchase_orders USING btree ("businessUnit");


--
-- Name: purchase_orders_expenseId_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "purchase_orders_expenseId_key" ON public.purchase_orders USING btree ("expenseId");


--
-- Name: purchase_orders_number_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX purchase_orders_number_key ON public.purchase_orders USING btree (number);


--
-- Name: purchase_orders_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX purchase_orders_status_idx ON public.purchase_orders USING btree (status);


--
-- Name: purchase_orders_supplierId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "purchase_orders_supplierId_idx" ON public.purchase_orders USING btree ("supplierId");


--
-- Name: quote_items_quoteId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "quote_items_quoteId_idx" ON public.quote_items USING btree ("quoteId");


--
-- Name: quotes_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "quotes_businessUnit_idx" ON public.quotes USING btree ("businessUnit");


--
-- Name: quotes_clientId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "quotes_clientId_idx" ON public.quotes USING btree ("clientId");


--
-- Name: quotes_convertedInvoiceId_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX "quotes_convertedInvoiceId_key" ON public.quotes USING btree ("convertedInvoiceId");


--
-- Name: quotes_number_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX quotes_number_key ON public.quotes USING btree (number);


--
-- Name: quotes_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX quotes_status_idx ON public.quotes USING btree (status);


--
-- Name: reconciliation_txs_reconciliationId_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "reconciliation_txs_reconciliationId_idx" ON public.reconciliation_txs USING btree ("reconciliationId");


--
-- Name: reconciliation_txs_status_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX reconciliation_txs_status_idx ON public.reconciliation_txs USING btree (status);


--
-- Name: recurring_payments_businessUnit_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "recurring_payments_businessUnit_idx" ON public.recurring_payments USING btree ("businessUnit");


--
-- Name: recurring_payments_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "recurring_payments_isActive_idx" ON public.recurring_payments USING btree ("isActive");


--
-- Name: recurring_payments_nextDueDate_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "recurring_payments_nextDueDate_idx" ON public.recurring_payments USING btree ("nextDueDate");


--
-- Name: suppliers_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "suppliers_isActive_idx" ON public.suppliers USING btree ("isActive");


--
-- Name: suppliers_name_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX suppliers_name_idx ON public.suppliers USING btree (name);


--
-- Name: suppliers_rnc_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX suppliers_rnc_key ON public.suppliers USING btree (rnc);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_role_isActive_idx; Type: INDEX; Schema: public; Owner: hax_user
--

CREATE INDEX "users_role_isActive_idx" ON public.users USING btree (role, "isActive");


--
-- Name: _PaymentBankTx _PaymentBankTx_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public."_PaymentBankTx"
    ADD CONSTRAINT "_PaymentBankTx_A_fkey" FOREIGN KEY ("A") REFERENCES public.bank_transactions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PaymentBankTx _PaymentBankTx_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public."_PaymentBankTx"
    ADD CONSTRAINT "_PaymentBankTx_B_fkey" FOREIGN KEY ("B") REFERENCES public.payments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accounts accounts_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: alanube_requests alanube_requests_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.alanube_requests
    ADD CONSTRAINT "alanube_requests_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_requests approval_requests_approvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT "approval_requests_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_requests approval_requests_requestedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT "approval_requests_requestedById_fkey" FOREIGN KEY ("requestedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bank_reconciliations bank_reconciliations_bankAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT "bank_reconciliations_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES public.bank_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bank_reconciliations bank_reconciliations_closedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT "bank_reconciliations_closedById_fkey" FOREIGN KEY ("closedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bank_transactions bank_transactions_bankAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.bank_transactions
    ADD CONSTRAINT "bank_transactions_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES public.bank_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: crm_opportunities crm_opportunities_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.crm_opportunities
    ADD CONSTRAINT "crm_opportunities_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: depreciation_entries depreciation_entries_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT "depreciation_entries_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.fixed_assets(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: depreciation_entries depreciation_entries_journalEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT "depreciation_entries_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fixed_assets fixed_assets_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT "fixed_assets_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoice_items invoice_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT "invoice_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_fromQuoteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_fromQuoteId_fkey" FOREIGN KEY ("fromQuoteId") REFERENCES public.quotes("convertedInvoiceId") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_originalInvoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_originalInvoiceId_fkey" FOREIGN KEY ("originalInvoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_creditAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_creditAccountId_fkey" FOREIGN KEY ("creditAccountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_entries journal_entries_debitAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_debitAccountId_fkey" FOREIGN KEY ("debitAccountId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_entries journal_entries_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_payrollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_payrollId_fkey" FOREIGN KEY ("payrollId") REFERENCES public.payrolls(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payroll_additions payroll_additions_payrollItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payroll_additions
    ADD CONSTRAINT "payroll_additions_payrollItemId_fkey" FOREIGN KEY ("payrollItemId") REFERENCES public.payroll_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payroll_items payroll_items_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payroll_items
    ADD CONSTRAINT "payroll_items_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payroll_items payroll_items_payrollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.payroll_items
    ADD CONSTRAINT "payroll_items_payrollId_fkey" FOREIGN KEY ("payrollId") REFERENCES public.payrolls(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.product_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quote_items quote_items_quoteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT "quote_items_quoteId_fkey" FOREIGN KEY ("quoteId") REFERENCES public.quotes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotes quotes_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT "quotes_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quotes quotes_opportunityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT "quotes_opportunityId_fkey" FOREIGN KEY ("opportunityId") REFERENCES public.crm_opportunities(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reconciliation_txs reconciliation_txs_reconciliationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hax_user
--

ALTER TABLE ONLY public.reconciliation_txs
    ADD CONSTRAINT "reconciliation_txs_reconciliationId_fkey" FOREIGN KEY ("reconciliationId") REFERENCES public.bank_reconciliations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: hax_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 5eiLBrekdCI3gPGSKzfKm5aDCmdDzO5UR5GNpoF3ao5jveFOpy122M0C7j29rrb

